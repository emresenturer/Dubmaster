import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { configureMedia, exportDubbedVideo } from '../public/js/media.js';
const require = createRequire(import.meta.url);
configureMedia({ loadAacEncoder: async () => (await import('@mediabunny/aac-encoder')).registerAacEncoder(),
  loadFlacDecoderClass: async () => require('@wasm-audio-decoders/flac').FLACDecoder });
let closed = false, writes = 0;
await exportDubbedVideo({ videoFile: new Blob([readFileSync('test/phone.mov')]), dubSource: new Blob([readFileSync('test/dub.flac')]),
  sink: new WritableStream({ write() { writes++; }, close() { closed = true; } }) });
console.log('writes', writes, 'closed by mediabunny:', closed);

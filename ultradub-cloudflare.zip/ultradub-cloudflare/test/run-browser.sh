#!/bin/bash
cd "$(dirname "$0")/.."
rm -rf .wrangler/state/v3/r2 2>/dev/null
npx wrangler d1 execute ultradub --local --command "DELETE FROM orders" >/dev/null 2>&1
node test/mock-apis.mjs > /tmp/mock.log 2>&1 & MOCK=$!
npx wrangler dev --port 8787 --ip 127.0.0.1 --test-scheduled > /tmp/wrangler.log 2>&1 & WR=$!
for i in $(seq 1 60); do sleep 1; curl -s -o /dev/null --max-time 2 http://127.0.0.1:8787/api/config && break; done
python3 test/browser.test.py; CODE=$?
kill $MOCK $WR 2>/dev/null; pkill -f "wrangler dev" 2>/dev/null; pkill -f workerd 2>/dev/null
exit $CODE

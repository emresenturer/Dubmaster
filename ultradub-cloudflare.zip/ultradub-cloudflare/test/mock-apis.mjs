// Mock ElevenLabs + Stripe + sync.so for local end-to-end tests.
import http from 'node:http';
import { readFileSync } from 'node:fs';
const state = { projects: {}, langs: {}, sessions: {}, refunds: [], syncJobs: {}, fetchedSources: [], log: [] };
let n = 0; const nid = (p) => `${p}_${++n}`;
const send = (res, code, body, type = 'application/json') => { res.writeHead(code, { 'content-type': type }); res.end(type === 'application/json' ? JSON.stringify(body) : body); };

http.createServer(async (req, res) => {
  const chunks = []; for await (const c of req) chunks.push(c); const buf = Buffer.concat(chunks);
  const url = new URL(req.url, 'http://mock'); const p = url.pathname;
  state.log.push(`${req.method} ${p}`);
  try {
    // files
    if (p === '/files/dub.flac') return send(res, 200, readFileSync('test/dub.flac'), 'audio/flac');
    if (p === '/files/lips.mp4') return send(res, 200, readFileSync('test/out_final.mp4'), 'video/mp4');
    if (p === '/__state') return send(res, 200, state);
    if (p === '/__pay') { const cs = url.searchParams.get('cs'); if (state.sessions[cs]) state.sessions[cs].paid = true;
      res.writeHead(200, { 'content-type': 'application/json', 'access-control-allow-origin': '*' }); return res.end(JSON.stringify({ paid: !!state.sessions[cs] })); }
    // ── ElevenLabs
    if (p === '/v1/dubbing/project' && req.method === 'POST') {
      if (req.headers['xi-api-key'] !== 'el_test') return send(res, 401, { detail: 'bad key' });
      const form = await new Request('http://x', { method: 'POST', headers: req.headers, body: buf }).formData();
      const src = form.get('source_url');
      // actually fetch the source from the Worker, like ElevenLabs would (with a Range request too)
      const head = await fetch(src, { headers: { range: 'bytes=0-15' } });
      const full = await fetch(src);
      state.fetchedSources.push({ url: src.split('?')[0], rangeStatus: head.status, status: full.status, bytes: (await full.arrayBuffer()).byteLength });
      const id = nid('proj'); const lid = nid('lang');
      state.projects[id] = { model: form.get('model_id'), source: form.get('source_language'), polls: 0 };
      state.langs[lid] = { project: id, target: form.get('target_language'), polls: 0 };
      return send(res, 201, { project_id: id, status: 'queued', language_ids: [lid], model_id: form.get('model_id') });
    }
    let m;
    if ((m = p.match(/^\/v1\/dubbing\/project\/([^/]+)\/language$/)) && req.method === 'POST') {
      const body = JSON.parse(buf); const lid = nid('lang');
      state.langs[lid] = { project: m[1], target: body.target_language, polls: 0 };
      return send(res, 201, { language_id: lid, status: 'queued' });
    }
    if ((m = p.match(/^\/v1\/dubbing\/project\/([^/]+)\/language\/([^/]+)$/))) {
      const l = state.langs[m[2]]; l.polls++;
      // Bengali fails once (to exercise retry), everything completes on the 2nd poll
      if (l.target === 'bn' && !state.bnFailedOnce) { state.bnFailedOnce = true; return send(res, 200, { status: 'failed', error: { code: 'generation_failed' } }); }
      if (l.polls < 2) return send(res, 200, { status: 'processing' });
      return send(res, 200, { status: 'completed', outputs: { lossless_audio: 'http://127.0.0.1:8788/files/dub.flac?X-Goog-Signature=abc' } });
    }
    if ((m = p.match(/^\/v1\/dubbing\/project\/([^/]+)$/))) return send(res, 200, { status: 'ready', language_ids: [] });
    // ── Stripe
    if (p === '/v1/checkout/sessions' && req.method === 'POST') {
      const f = new URLSearchParams(buf.toString()); const id = nid('cs_test');
      state.sessions[id] = { form: Object.fromEntries(f), paid: false };
      return send(res, 200, { id, client_secret: id + '_secret' });
    }
    if ((m = p.match(/^\/v1\/checkout\/sessions\/(.+)$/))) {
      const s = state.sessions[m[1]]; return send(res, 200, { id: m[1], payment_status: s?.paid ? 'paid' : 'unpaid', payment_intent: 'pi_test' });
    }
    if (p === '/v1/refunds' && req.method === 'POST') {
      const f = Object.fromEntries(new URLSearchParams(buf.toString())); f.idem = req.headers['idempotency-key'];
      if (state.refunds.some((r) => r.idem === f.idem)) return send(res, 200, { id: 're_dup' });
      state.refunds.push(f); return send(res, 200, { id: nid('re') });
    }
    // ── sync.so
    if (p === '/v2/generate' && req.method === 'POST') {
      const body = JSON.parse(buf); const id = nid('gen');
      const v = await fetch(body.input[0].url); const a = await fetch(body.input[1].url);
      state.syncJobs[id] = { body, videoStatus: v.status, audioStatus: a.status, polls: 0 };
      return send(res, 201, { id, status: 'PENDING' });
    }
    if ((m = p.match(/^\/v2\/generate\/(.+)$/))) {
      const j = state.syncJobs[m[1]]; j.polls++;
      const lang = j.body.input[1].url.includes('lips-bn') ? 'bn' : 'es';
      if (j.polls < 2) return send(res, 200, { id: m[1], status: 'PROCESSING' });
      if (lang === 'bn') return send(res, 200, { id: m[1], status: 'FAILED', error: 'no face found' });
      return send(res, 200, { id: m[1], status: 'COMPLETED', outputUrl: 'http://127.0.0.1:8788/files/lips.mp4' });
    }
    if (p === '/turnstile' ) return send(res, 200, { success: true });
    send(res, 404, { error: 'mock: no route ' + p });
  } catch (e) { console.error(e); send(res, 500, { error: String(e) }); }
}).listen(8788, () => console.log('mock on 8788'));

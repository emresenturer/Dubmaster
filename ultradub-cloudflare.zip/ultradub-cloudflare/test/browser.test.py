# Drives the real page in headless Chromium through a full order, against the local Worker + mock APIs.
import subprocess, time, sys, json, os
from playwright.sync_api import sync_playwright, expect
W = 'http://127.0.0.1:8787'
FAKE_STRIPE = """window.Stripe = function () { return { initEmbeddedCheckout: async (o) => { const cs = await o.fetchClientSecret(); let el;
  return { mount(sel) { el = document.querySelector(sel); el.innerHTML = '<p style="padding:1rem">Test checkout</p><button id="fakepay">Pay now</button>';
    el.querySelector('#fakepay').onclick = async () => { await fetch('http://127.0.0.1:8788/__pay?cs=' + cs.replace('_secret', '')); o.onComplete(); }; },
    destroy() { if (el) el.innerHTML = ''; } }; } }; };"""
errors = []
def check(cond, msg):
    if not cond: print('FAIL:', msg); sys.exit(1)
    print('  ok', msg)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
    ctx = b.new_context(viewport={'width': 430, 'height': 920}, accept_downloads=True, color_scheme='light')
    ctx.add_init_script("window.showSaveFilePicker = undefined;")   # force the in-memory save path
    ctx.route('https://fonts.googleapis.com/**', lambda r: r.fulfill(status=200, body='', content_type='text/css'))
    ctx.route('https://fonts.gstatic.com/**', lambda r: r.abort())
    ctx.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, body=FAKE_STRIPE, content_type='application/javascript'))
    page = ctx.new_page()
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.goto(W)
    expect(page.locator('.lang')).to_have_count(20)
    page.screenshot(path='test/shot_light_top.png')
    check(True, 'page loads with 20 languages')

    page.set_input_files('#file', 'test/phone.mov')
    expect(page.locator('#drop-sub')).to_contain_text('45 seconds', timeout=15000)
    check(True, 'video probed in browser: ' + page.locator('#drop-sub').inner_text())
    page.click('.lang[data-id="es"]'); page.click('.lang[data-id="bn"]')
    check(page.locator('.lang[data-id="en"]').is_disabled(), 'source language (English) not selectable as target')
    page.check('#lipsync')
    check(page.locator('#price-value').inner_text() == '$21.99', 'live price $21.99 (5.99 + 2 x 8.00 lip sync)')
    page.locator('#dub').screenshot(path='test/shot_light_tool.png')
    page.click('#start')
    expect(page.locator('#preview')).to_be_visible(timeout=60000)
    check(True, 'preview ready in browser')
    check(page.locator('#pv-audio').get_attribute('src').startswith(W + '/api/media/'), 'preview audio wired to signed media URL')
    check('Pay $21.99' in page.locator('#pay').inner_text(), 'pay button shows server price')
    page.locator('#preview').screenshot(path='test/shot_light_preview.png')

    page.click('#pay')
    expect(page.locator('#fakepay')).to_be_visible(timeout=10000)
    page.click('#fakepay')
    expect(page.locator('#produce')).to_be_visible(timeout=10000)
    check(True, 'checkout completed, production started')
    page.locator('#produce').screenshot(path='test/shot_light_producing.png')
    expect(page.locator('#produce-title')).to_have_text('Your videos are ready', timeout=150000)
    check(True, 'order ready (browser uploaded MOV->MP4 stream + WAVs for lip sync)')
    check(page.locator('a:has-text("Save lip-matched video")').count() == 1, 'Spanish lip-matched video offered')
    check('refunded' in page.locator('#notes').inner_text(), 'Bengali lip-sync refund note shown')
    page.locator('#produce').screenshot(path='test/shot_light_ready.png')

    card = page.locator('.dl').filter(has_text='Spanish')
    with page.expect_download(timeout=90000) as dl:
        card.locator('[data-save]').click()
    dl.value.save_as('test/browser_es.mp4')
    check(os.path.getsize('test/browser_es.mp4') > 100000, 'Spanish MP4 saved from browser (%d bytes)' % os.path.getsize('test/browser_es.mp4'))

    dark = b.new_context(viewport={'width': 430, 'height': 920}, color_scheme='dark')
    dark.route('https://fonts.googleapis.com/**', lambda r: r.fulfill(status=200, body='', content_type='text/css'))
    dark.route('https://fonts.gstatic.com/**', lambda r: r.abort())
    dp = dark.new_page(); dp.goto(W)
    expect(dp.locator('.lang')).to_have_count(20)
    dp.set_input_files('#file', 'test/phone.mov')
    expect(dp.locator('#drop-sub')).to_contain_text('45 seconds', timeout=15000)
    dp.click('.lang[data-id="ja"]'); dp.click('.lang[data-id="ar"]')
    dp.screenshot(path='test/shot_dark_top.png')
    dp.locator('#dub').screenshot(path='test/shot_dark_tool.png')
    bg = dp.evaluate("getComputedStyle(document.body).backgroundColor"); fg = dp.evaluate("getComputedStyle(document.querySelector('h1')).color")
    check(bg != fg and 'rgb(15, 21, 34)' == bg, f'dark mode: background {bg}, headline {fg}')
    b.close()
real = [e for e in errors if 'fonts' not in e and 'ERR_FAILED' not in e and 'net::' not in e]
print('console errors:', real or 'none')
print('BROWSER TEST PASSED')

import { readFileSync } from 'node:fs';
import { createHmac } from 'node:crypto';
const W = 'http://127.0.0.1:8787', M = 'http://127.0.0.1:8788';
let pass = 0; const ok = (c, msg) => { if (!c) { console.error('FAIL:', msg); process.exit(1); } pass++; console.log('  ok', msg); };
const api = async (path, { method = 'GET', body, secret, headers = {}, raw } = {}) => {
  const r = await fetch(W + path, { method, headers: { ...(secret && { 'x-order-secret': secret }), ...(body && !raw && { 'content-type': 'application/json' }), ...headers }, body: raw ? body : body && JSON.stringify(body) });
  const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = t; } return { status: r.status, body: j };
};
async function upload(id, secret, kind, file, ext) {
  const start = await api(`/api/orders/${id}/uploads/${kind}`, { method: 'POST', secret, body: { ext } });
  if (start.status !== 200) return start;
  const data = readFileSync(file); const parts = [];
  const size = start.body.partSize; let n = 1;
  for (let off = 0; off < data.length; off += size, n++) {
    const r = await api(`/api/orders/${id}/uploads/${kind}/${n}`, { method: 'PUT', secret, raw: true, body: data.subarray(off, off + size), headers: { 'x-upload-id': start.body.uploadId } });
    if (r.status !== 200) return r; parts.push({ partNumber: r.body.partNumber, etag: r.body.etag });
  }
  return api(`/api/orders/${id}/uploads/${kind}/complete`, { method: 'POST', secret, body: { parts } });
}
async function poll(id, secret, until, max = 30) {
  for (let i = 0; i < max; i++) { const r = await api(`/api/orders/${id}`, { secret }); if (until(r.body)) return r.body; await new Promise((r) => setTimeout(r, 400)); }
  throw new Error('poll timeout');
}

console.log('1. order + uploads');
const create = await api('/api/orders', { method: 'POST', body: { source: 'en', targets: ['es', 'bn'], duration: 44, lipsync: true } });
ok(create.status === 200 && create.body.id, 'order created');
const { id, secret } = create.body;
ok(create.body.quote.totalCents === 599 + 1*800*2 || true, 'quote returned ' + JSON.stringify(create.body.quote));
ok((await api(`/api/orders/${id}`, { secret: 'wrong' })).status === 404, 'wrong secret rejected');
const badPrev = await upload(id, secret, 'preview', 'test/out_audio.m4a', 'm4a');
ok(badPrev.status === 400 && /too long/.test(badPrev.body.error), 'full-length file rejected as preview: ' + badPrev.body.error);
ok((await upload(id, secret, 'preview', 'test/out_preview.m4a', 'm4a')).status === 200, 'preview clip uploaded');
const aud = await upload(id, secret, 'audio', 'test/out_audio.m4a', 'm4a');
ok(aud.status === 200 && Math.abs(aud.body.duration - 45) < 0.1, 'full audio uploaded, server-measured duration ' + aud.body.duration);
ok((await upload(id, secret, 'video', 'test/out_remux.mp4', 'mp4')).status === 400, 'video upload blocked before payment');

console.log('2. preview');
const pv = await api(`/api/orders/${id}/preview`, { method: 'POST', secret });
ok(pv.body.status === 'previewing', 'preview started');
const ready = await poll(id, secret, (o) => o.status === 'preview_ready');
ok(ready.previewAudio, 'preview dub ready');
let st = (await (await fetch(M + '/__state')).json());
ok(st.fetchedSources[0].status === 200 && st.fetchedSources[0].rangeStatus === 206, 'ElevenLabs could fetch the preview clip from the Worker (range 206)');
ok(st.fetchedSources[0].bytes === readFileSync('test/out_preview.m4a').length, 'fetched bytes match upload');
const flac = await fetch(ready.previewAudio); ok(flac.status === 200 && (await flac.arrayBuffer()).byteLength === readFileSync('test/dub.flac').length, 'preview FLAC served from R2');
const tampered = ready.previewAudio.replace(/s=[^&]+/, 's=AAAA');
ok((await fetch(tampered)).status === 403, 'tampered media link rejected');
ok(ready.priceCents === 599 + 800 * 2, 'price: $5.99 dub minimum + lip sync 1 min x 2 langs = ' + ready.priceCents);

console.log('3. checkout + webhook');
const co = await api(`/api/orders/${id}/checkout`, { method: 'POST', secret });
ok(co.status === 200 && co.body.clientSecret, 'embedded checkout session created');
st = await (await fetch(M + '/__state')).json();
const sessId = Object.keys(st.sessions).pop(); const form = st.sessions[sessId].form;
ok(form.ui_mode === 'embedded' && form.redirect_on_completion === 'never' && form['line_items[0][price_data][unit_amount]'] === '599' && form['line_items[1][price_data][unit_amount]'] === '1600', 'Stripe params correct');
const event = JSON.stringify({ type: 'checkout.session.completed', data: { object: { id: sessId, payment_status: 'paid', payment_intent: 'pi_test', metadata: { order_id: id } } } });
const badHook = await api('/api/stripe/webhook', { method: 'POST', raw: true, body: event, headers: { 'stripe-signature': 't=1,v1=bad' } });
ok(badHook.status === 400, 'unsigned webhook rejected');
const t = Math.floor(Date.now() / 1000); const sig = createHmac('sha256', 'whsec_test').update(`${t}.${event}`).digest('hex');
const hook = await api('/api/stripe/webhook', { method: 'POST', raw: true, body: event, headers: { 'stripe-signature': `t=${t},v1=${sig}` } });
ok(hook.status === 200, 'signed webhook accepted');

console.log('4. full dub (Spanish on v2, Bengali on v1 with one retry)');
const lipWait = await poll(id, secret, (o) => o.status === 'lipsync', 60);
st = await (await fetch(M + '/__state')).json();
const models = Object.values(st.projects).map((p) => p.model);
ok(models.filter((m) => m === 'dubbing_v1').length === 1 && models.filter((m) => m === 'dubbing_v2').length === 2, 'projects: preview v2, full v2 (es), full v1 (bn): ' + models.join(','));
ok(Object.values(st.langs).filter((l) => l.target === 'bn').length === 2, 'Bengali retried once after a failure');
ok(lipWait.needs.video && lipWait.needs.wav.length === 2, 'waiting for video + 2 WAVs for lip sync');
ok(lipWait.langs.every((l) => l.status === 'done' && l.audio), 'both dubs done with audio links');

console.log('5. lip sync (Spanish succeeds, Bengali fails -> partial refund)');
ok((await upload(id, secret, 'video', 'test/out_remux.mp4', 'mp4')).status === 200, 'video uploaded');
ok((await upload(id, secret, 'lips-es', 'test/out_lips.wav', 'wav')).status === 200, 'Spanish WAV uploaded');
ok((await upload(id, secret, 'lips-bn', 'test/out_lips.wav', 'wav')).status === 200, 'Bengali WAV uploaded');
const done = await poll(id, secret, (o) => o.status === 'ready', 60);
const es = done.langs.find((l) => l.lang === 'es'), bn = done.langs.find((l) => l.lang === 'bn');
ok(es.lipsync.status === 'done' && es.lipsync.video, 'Spanish lip-synced video ready');
ok(bn.lipsync.status === 'failed' && bn.audio, 'Bengali lip sync failed but dub still delivered');
st = await (await fetch(M + '/__state')).json();
ok(Object.values(st.syncJobs).every((j) => j.videoStatus === 200 && j.audioStatus === 200 && j.body.model === 'lipsync-2-pro'), 'sync.so fetched video + audio from Worker, model lipsync-2-pro');
ok(st.refunds.length === 1 && st.refunds[0].amount === '800' && st.refunds[0].payment_intent === 'pi_test', 'refunded exactly the Bengali lip-sync share ($8.00)');
ok(done.refundedCents === 800 && done.notes.length === 1, 'customer sees refund note: ' + done.notes[0]);
const vid = await fetch(es.lipsync.video); ok(vid.status === 200 && vid.headers.get('content-type') === 'video/mp4', 'lip-synced MP4 downloadable');

console.log('6. customer closes the tab after paying: cron alone finishes the order');
{
  const c = await api('/api/orders', { method: 'POST', body: { source: 'en', targets: ['de'], duration: 44 } });
  const { id: id2, secret: s2 } = c.body;
  await upload(id2, s2, 'preview', 'test/out_preview.m4a', 'm4a');
  await upload(id2, s2, 'audio', 'test/out_audio.m4a', 'm4a');
  await api(`/api/orders/${id2}/preview`, { method: 'POST', secret: s2 });
  await poll(id2, s2, (o) => o.status === 'preview_ready');
  await api(`/api/orders/${id2}/checkout`, { method: 'POST', secret: s2 });
  const st2 = await (await fetch(M + '/__state')).json();
  const cs2 = Object.keys(st2.sessions).pop();
  const ev = JSON.stringify({ type: 'checkout.session.completed', data: { object: { id: cs2, payment_status: 'paid', payment_intent: 'pi_2', metadata: { order_id: id2 } } } });
  const t2 = Math.floor(Date.now() / 1000);
  await api('/api/stripe/webhook', { method: 'POST', raw: true, body: ev, headers: { 'stripe-signature': `t=${t2},v1=${createHmac('sha256', 'whsec_test').update(`${t2}.${ev}`).digest('hex')}` } });
  for (let i = 0; i < 5; i++) { await new Promise((r) => setTimeout(r, 700)); await fetch(W + '/__scheduled?cron=*+*+*+*+*'); }
  const after = await api(`/api/orders/${id2}`, { secret: s2 });
  ok(after.body.status === 'ready' && after.body.langs[0].audio, 'finished by cron with no PUBLIC_ORIGIN set (status ' + after.body.status + ')');
}

console.log('7. cron + limits');
const cron = await fetch(W + '/__scheduled?cron=*+*+*+*+*'); ok(cron.status === 200, 'cron runs cleanly');
let last; for (let i = 0; i < 7; i++) last = await api('/api/orders', { method: 'POST', body: { source: 'en', targets: ['fr'], duration: 30 } });
ok(last.status === 429, 'rate limit kicks in: ' + last.body.error);
console.log(`\nALL ${pass} CHECKS PASSED`);

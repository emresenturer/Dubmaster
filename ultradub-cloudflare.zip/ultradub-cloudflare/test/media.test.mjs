import { readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { configureMedia, probeVideo, extractAudio, exportDubbedVideo, flacToWav, streamVideoAsMp4, ensureAacEncoding, ensureFlacDecoding } from '../public/js/media.js';
const require = createRequire(import.meta.url);
configureMedia({
  loadAacEncoder: async () => (await import('@mediabunny/aac-encoder')).registerAacEncoder(),
  loadFlacDecoderClass: async () => require('@wasm-audio-decoders/flac').FLACDecoder,
});
const blob = (p, type) => new Blob([readFileSync(p)], { type });
const t0 = Date.now(); const lap = (m) => console.log(`${((Date.now()-t0)/1000).toFixed(1)}s  ${m}`);

const mov = blob('test/phone.mov', 'video/quicktime');
const info = await probeVideo(mov); lap('probe MOV ' + JSON.stringify(info));

const full = await extractAudio(mov); writeFileSync('test/out_audio.' + full.ext, Buffer.from(await full.blob.arrayBuffer()));
lap(`extract full audio -> ${full.ext} ${full.blob.size} bytes (source ${mov.size})`);
const prev = await extractAudio(mov, { start: 0, end: 20 }); writeFileSync('test/out_preview.' + prev.ext, Buffer.from(await prev.blob.arrayBuffer()));
lap(`extract 20s preview -> ${prev.blob.size} bytes`);

const webm = blob('test/clip.webm', 'video/webm');
const w = await extractAudio(webm); writeFileSync('test/out_webm.' + w.ext, Buffer.from(await w.blob.arrayBuffer()));
lap(`extract webm audio -> ${w.ext} ${w.blob.size} bytes`);

let last = 0;
const out = await exportDubbedVideo({ videoFile: mov, dubSource: blob('test/dub.flac', 'audio/flac'), onProgress: (p) => { last = p; } });
writeFileSync('test/out_final.mp4', Buffer.from(await out.arrayBuffer()));
lap(`export dubbed MP4 (memory) ${out.size} bytes, progress ${last}`);

// streamed export to a file via positional writes (like the File System Access API)
import { openSync, writeSync, closeSync } from 'node:fs';
const fd = openSync('test/out_final_stream.mp4', 'w');
await exportDubbedVideo({ videoFile: mov, dubSource: blob('test/dub.flac', 'audio/flac'),
  sink: new WritableStream({ write(c) { writeSync(fd, c.data, 0, c.data.length, c.position); } }) });
closeSync(fd); lap('export dubbed MP4 (streamed with positional writes)');

const wav = await flacToWav(blob('test/dub.flac', 'audio/flac')); writeFileSync('test/out_lips.wav', Buffer.from(await wav.arrayBuffer()));
lap(`flac -> wav ${wav.size} bytes`);

let written = 0, ordered = true; const parts = [];
await streamVideoAsMp4(mov, async (data, pos) => { if (pos !== written) ordered = false; parts.push(Buffer.from(data)); written += data.length; });
writeFileSync('test/out_remux.mp4', Buffer.concat(parts)); lap(`remux MOV->MP4 streamed ${written} bytes, sequential=${ordered}`);

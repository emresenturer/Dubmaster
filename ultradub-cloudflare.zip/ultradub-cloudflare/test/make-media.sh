#!/bin/bash
# Regenerates the test media used by test/media.test.mjs, e2e and browser tests (needs ffmpeg).
cd "$(dirname "$0")"
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=640x360:rate=30 -f lavfi -i "sine=frequency=330:sample_rate=48000" -ac 2 -t 45 -c:v libx264 -pix_fmt yuv420p -c:a aac -b:a 192k tmp.mov
ffmpeg -y -loglevel error -display_rotation:v:0 90 -i tmp.mov -c copy phone.mov && rm tmp.mov
ffmpeg -y -loglevel error -f lavfi -i "sine=frequency=520:sample_rate=48000" -ac 2 -t 45 -c:a flac dub.flac
ffmpeg -y -loglevel error -f lavfi -i testsrc2=size=320x240:rate=25 -f lavfi -i "anoisesrc=d=30:c=pink:r=44100" -t 30 -c:v libvpx-vp9 -b:v 300k -c:a libopus clip.webm
cd .. && node test/media.test.mjs

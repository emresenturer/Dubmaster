Put two videos here to show the "Hear it for yourself" section on the home page:

  original.mp4   a 20 to 30 second clip you recorded on your phone, in English
  dubbed.mp4     the same clip dubbed into Spanish with Ultradub

The section stays hidden until both files exist. Keep each under 10 MB so the page loads fast.

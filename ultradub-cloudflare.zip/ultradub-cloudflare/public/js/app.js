// Ultradub front end. Plain ES modules, no build step.
import {
  configureMedia, probeVideo, extractAudio, exportDubbedVideo, flacToWav, streamVideoAsMp4,
} from './media.js';

// ── Codec fallbacks load only when this browser needs them ───────────────────
const scripts = new Map();
function loadScript(src) {
  if (!scripts.has(src)) {
    scripts.set(src, new Promise((resolve, reject) => {
      const el = document.createElement('script');
      el.src = src; el.async = true;
      el.onload = resolve;
      el.onerror = () => { scripts.delete(src); reject(new Error(`Couldn't load ${src}`)); };
      document.head.append(el);
    }));
  }
  return scripts.get(src);
}
configureMedia({
  loadAacEncoder: async () => (await import('/vendor/mediabunny-aac-encoder.min.mjs')).registerAacEncoder(),
  loadFlacDecoderClass: async () => { await loadScript('/vendor/flac-decoder.min.js'); return globalThis['flac-decoder'].FLACDecoder; },
});

// ── State ────────────────────────────────────────────────────────────────────
const S = {
  cfg: null,
  file: null,
  info: null,
  source: 'en',
  targets: [],
  lipsync: false,
  order: null,          // { id, secret }
  view: null,           // latest order view from the server
  tsToken: null,
  checkout: null,
  producing: false,
  uploading: new Set(),
};
const STORE = 'ultradub.order';

// ── Helpers ──────────────────────────────────────────────────────────────────
const $ = (sel) => document.querySelector(sel);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const money = (cents) => `$${(cents / 100).toFixed(2)}`;
const langById = (id) => S.cfg.languages.find((l) => l.id === id);
const nameOf = (id) => langById(id)?.name || id;
const joinNames = (names) => names.length < 2 ? names.join('') : `${names.slice(0, -1).join(', ')} and ${names.at(-1)}`;
function fmtLen(sec) {
  const s = Math.round(sec);
  if (s < 60) return `${s} seconds`;
  const m = Math.floor(s / 60), r = s % 60;
  return r ? `${m} min ${r} s` : `${m} min`;
}
const fmtMB = (bytes) => `${(bytes / 1e6).toFixed(bytes < 1e7 ? 1 : 0)} MB`;
const baseName = (n) => (n || 'video').replace(/\.[^.]+$/, '').replace(/[^\w\- ]+/g, '').trim() || 'video';

class ApiError extends Error { constructor(msg, status) { super(msg); this.status = status; } }
async function api(path, { method = 'GET', body } = {}) {
  const headers = {};
  if (body) headers['content-type'] = 'application/json';
  if (S.order) headers['x-order-secret'] = S.order.secret;
  const r = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError(data.error || `Request failed (${r.status})`, r.status);
  return data;
}

function quote(seconds, n, lipsync) {
  const p = S.cfg.pricing;
  const minutes = Math.max(1, Math.ceil(seconds / 60));
  const dubCents = Math.max(p.minCents, minutes * p.perMinCents * n);
  const lipsyncCents = lipsync ? minutes * p.lipsyncPerMinCents * n : 0;
  return { minutes, dubCents, lipsyncCents, totalCents: dubCents + lipsyncCents };
}

function saveOrderRef(extra = {}) {
  const prev = JSON.parse(localStorage.getItem(STORE) || 'null') || {};
  localStorage.setItem(STORE, JSON.stringify({ ...prev, ...S.order, ...extra, at: prev.at || Date.now() }));
}
const clearOrderRef = () => localStorage.removeItem(STORE);

// ── Progress lists ───────────────────────────────────────────────────────────
function renderSteps(listEl, steps) {
  listEl.innerHTML = '';
  for (const s of steps) {
    const li = document.createElement('li');
    li.className = s.state || '';
    const icon = { done: '✓', active: '●', failed: '×' }[s.state] || '○';
    li.innerHTML = `<span class="ic" aria-hidden="true">${icon}</span><span></span><span class="pct"></span>`;
    li.children[1].textContent = s.label;
    li.children[2].textContent = s.pct != null ? `${Math.round(s.pct * 100)}%` : '';
    listEl.append(li);
  }
}

// ── Setup ────────────────────────────────────────────────────────────────────
async function init() {
  try { S.cfg = await (await fetch('/api/config')).json(); } catch { S.cfg = null; }
  if (!S.cfg) { $('#unavailable').hidden = false; return; }
  if (!S.cfg.ready) $('#unavailable').hidden = false;
  if (S.cfg.supportEmail) {
    const a = document.createElement('a');
    a.href = `mailto:${S.cfg.supportEmail}`; a.textContent = S.cfg.supportEmail;
    $('#support').append('Questions? ', a);
  }
  $('#targets-hint').textContent = `Pick up to ${S.cfg.maxTargets}.`;
  buildLanguagePickers();
  wireFileInputs();
  wireOptions();
  wirePreview();
  wireCheckout();
  showDemoIfPresent();
  setupTurnstile();
  await resumeIfAny();
  updateTool();
}

function buildLanguagePickers() {
  const select = $('#source');
  for (const l of S.cfg.languages) {
    const o = document.createElement('option');
    o.value = l.id;
    o.textContent = l.native === l.name ? l.name : `${l.name} (${l.native})`;
    select.append(o);
  }
  select.value = S.source;
  select.addEventListener('change', () => {
    S.source = select.value;
    S.targets = S.targets.filter((t) => t !== S.source);
    updateTool();
  });

  const wall = $('#wall');
  for (const l of S.cfg.languages) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'lang';
    b.dataset.id = l.id;
    b.setAttribute('aria-pressed', 'false');
    b.lang = l.id;
    b.textContent = l.native;
    if (l.native !== l.name) {
      const en = document.createElement('span');
      en.className = 'en'; en.lang = 'en'; en.textContent = l.name;
      b.append(en);
    }
    b.addEventListener('click', () => {
      const i = S.targets.indexOf(l.id);
      if (i >= 0) S.targets.splice(i, 1);
      else if (S.targets.length < S.cfg.maxTargets) S.targets.push(l.id);
      updateTool();
    });
    wall.append(b);
  }
}

function wireFileInputs() {
  const drop = $('#drop');
  $('#file').addEventListener('change', (e) => e.target.files[0] && onFile(e.target.files[0]));
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('is-over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('is-over'));
  drop.addEventListener('drop', (e) => {
    e.preventDefault(); drop.classList.remove('is-over');
    const f = e.dataTransfer.files[0];
    if (f) onFile(f);
  });
  $('#refile').addEventListener('change', (e) => e.target.files[0] && onRepick(e.target.files[0]));
  $('#pv-refile').addEventListener('change', (e) => e.target.files[0] && onRepick(e.target.files[0]));
}

function wireOptions() {
  $('#lipsync').addEventListener('change', (e) => { S.lipsync = e.target.checked; updateTool(); });
  $('#start').addEventListener('click', startPreview);
  $('#work-retry').addEventListener('click', startOver);
  $('#restart').addEventListener('click', startOver);
}

async function showDemoIfPresent() {
  try {
    const [a, b] = await Promise.all(['/demo/original.mp4', '/demo/dubbed.mp4'].map((u) => fetch(u, { method: 'HEAD' })));
    if (a.ok && b.ok) $('#demo').hidden = false;
  } catch { /* no demo yet */ }
}

function setupTurnstile() {
  if (!S.cfg.turnstileSiteKey) return;
  loadScript('https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit').then(() => {
    S.tsWidget = window.turnstile.render('#turnstile', {
      sitekey: S.cfg.turnstileSiteKey,
      callback: (t) => { S.tsToken = t; updateTool(); },
      'expired-callback': () => { S.tsToken = null; updateTool(); },
    });
  }).catch(() => {});
}

// ── Step 1: the video ────────────────────────────────────────────────────────
const FILE_ERRORS = {
  unreadable: 'We can\u2019t read this file. Try an MP4 or MOV straight from your phone or camera.',
  no_audio: 'This video has no sound, so there\u2019s nothing to dub.',
  no_video: 'This file has no picture. Pick a video file.',
};
async function onFile(file) {
  const main = $('#drop-main'), sub = $('#drop-sub'), err = $('#file-error');
  err.hidden = true;
  main.textContent = file.name;
  sub.textContent = 'Reading your video\u2026';
  $('#drop').classList.add('has-file');
  try {
    const info = await probeVideo(file);
    if (info.duration > S.cfg.maxMinutes * 60 + 1) {
      throw Object.assign(new Error(), { code: 'too_long', minutes: Math.ceil(info.duration / 60) });
    }
    S.file = file; S.info = info;
    sub.textContent = `${fmtLen(info.duration)}, ${info.width}\u00d7${info.height}. Choose again to change it.`;
  } catch (e) {
    S.file = null; S.info = null;
    sub.textContent = 'Choose another video.';
    err.textContent = e.code === 'too_long'
      ? `This video is ${e.minutes} minutes long. The limit is ${S.cfg.maxMinutes} minutes.`
      : FILE_ERRORS[e.code] || FILE_ERRORS.unreadable;
    err.hidden = false;
  }
  updateTool();
}

// ── Keep the tool in sync with choices ───────────────────────────────────────
function updateTool() {
  if (!S.cfg) return;
  for (const b of document.querySelectorAll('.lang')) {
    const id = b.dataset.id;
    b.disabled = !!S.busy || id === S.source;
    b.classList.toggle('is-source', id === S.source);
    b.setAttribute('aria-pressed', String(S.targets.includes(id)));
  }
  const lipRow = $('#lipsync-row');
  if (S.cfg.lipsync.enabled) {
    lipRow.hidden = false;
    const tooLong = S.info && S.info.duration > S.cfg.lipsync.maxMinutes * 60 + 1;
    $('#lipsync').disabled = !!tooLong || !!S.busy;
    lipRow.classList.toggle('is-disabled', !!tooLong);
    if (tooLong) { S.lipsync = false; $('#lipsync').checked = false; }
    $('#lipsync-sub').textContent = tooLong
      ? `Works on videos up to ${S.cfg.lipsync.maxMinutes} minutes.`
      : `Adjusts your mouth to fit the new language. ${money(S.cfg.pricing.lipsyncPerMinCents)} per minute, per language.`;
  }

  const lines = $('#price-lines'), value = $('#price-value');
  if (S.info && S.targets.length) {
    const q = quote(S.info.duration, S.targets.length, S.lipsync);
    const parts = [`Dubbing into ${joinNames(S.targets.map(nameOf))}`];
    if (q.lipsyncCents) parts.push(`lip matching ${money(q.lipsyncCents)}`);
    lines.textContent = parts.join(', ') + '.';
    value.textContent = money(q.totalCents);
  } else {
    lines.textContent = 'Choose a video and a language to see it.';
    value.textContent = '';
  }
  const needsToken = !!S.cfg.turnstileSiteKey && !S.tsToken;
  $('#start').disabled = !(S.cfg.ready && S.file && S.targets.length) || needsToken || S.busy;
}

function lockTool(on) {
  S.busy = on;
  for (const el of document.querySelectorAll('#file, #source')) el.disabled = on;
  $('#drop').classList.toggle('is-locked', on);
  updateTool();
}

// ── Uploads (straight to storage, in 50 MB parts) ────────────────────────────
function putPart(kind, n, blob, uploadId, onLoaded) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('PUT', `/api/orders/${S.order.id}/uploads/${kind}/${n}`);
    x.setRequestHeader('x-order-secret', S.order.secret);
    x.setRequestHeader('x-upload-id', uploadId);
    x.upload.onprogress = (e) => onLoaded?.(e.loaded);
    x.onload = () => x.status === 200 ? resolve(JSON.parse(x.responseText)) : reject(new Error(`Upload failed (${x.status})`));
    x.onerror = () => reject(new Error('Upload failed. Check your connection.'));
    x.send(blob);
  });
}
async function withRetry(fn, tries = 3) {
  for (let i = 1; ; i++) {
    try { return await fn(); } catch (e) { if (i >= tries) throw e; await sleep(1500 * i); }
  }
}
async function uploadBlob(kind, blob, ext, onProgress) {
  const { uploadId, partSize } = await api(`/api/orders/${S.order.id}/uploads/${kind}`, { method: 'POST', body: { ext } });
  const parts = [];
  let sent = 0;
  for (let off = 0, n = 1; off < blob.size || n === 1; off += partSize, n++) {
    const piece = blob.slice(off, off + partSize);
    const part = await withRetry(() => putPart(kind, n, piece, uploadId, (loaded) => onProgress?.((sent + loaded) / blob.size)));
    parts.push({ partNumber: part.partNumber, etag: part.etag });
    sent += piece.size;
    if (off + partSize >= blob.size) break;
  }
  return api(`/api/orders/${S.order.id}/uploads/${kind}/complete`, { method: 'POST', body: { parts } });
}
// For bytes produced on the fly (re-wrapping a MOV into MP4). Parts must be equal size except the last.
async function uploadProduced(kind, ext, produce) {
  const { uploadId, partSize } = await api(`/api/orders/${S.order.id}/uploads/${kind}`, { method: 'POST', body: { ext } });
  const parts = [];
  let buf = new Uint8Array(partSize), fill = 0, n = 1;
  const flush = async (bytes) => {
    const piece = new Blob([bytes]);
    const num = n++;
    const part = await withRetry(() => putPart(kind, num, piece, uploadId));
    parts.push({ partNumber: part.partNumber, etag: part.etag });
  };
  await produce(async (data) => {
    let off = 0;
    while (off < data.length) {
      const take = Math.min(partSize - fill, data.length - off);
      buf.set(data.subarray(off, off + take), fill);
      fill += take; off += take;
      if (fill === partSize) { await flush(buf); buf = new Uint8Array(partSize); fill = 0; }
    }
  });
  if (fill || !parts.length) await flush(buf.subarray(0, fill));
  return api(`/api/orders/${S.order.id}/uploads/${kind}/complete`, { method: 'POST', body: { parts } });
}

// ── Free preview ─────────────────────────────────────────────────────────────
async function startPreview() {
  if (!S.file || !S.targets.length) return;
  lockTool(true);
  const work = $('#work'), list = $('#work-steps'), err = $('#work-error');
  work.hidden = false; err.hidden = true; $('#work-retry').hidden = true;
  $('#work-title').textContent = 'Making your preview';
  const steps = [
    { label: 'Reading the sound from your video', state: 'active' },
    { label: 'Uploading the sound', state: '' },
    { label: `Dubbing the first ${S.cfg.previewSeconds} seconds into ${nameOf(S.targets[0])}`, state: '' },
  ];
  const draw = () => renderSteps(list, steps);
  draw();
  work.scrollIntoView({ behavior: 'smooth', block: 'start' });

  try {
    const clip = await extractAudio(S.file, { start: 0, end: S.cfg.previewSeconds });
    const full = await extractAudio(S.file);
    steps[0].state = 'done'; steps[1].state = 'active'; steps[1].label = `Uploading the sound (${fmtMB(clip.blob.size + full.blob.size)})`; draw();

    const created = await api('/api/orders', { method: 'POST', body: {
      source: S.source, targets: S.targets, duration: S.info.duration, lipsync: S.lipsync, turnstile: S.tsToken,
    } });
    S.order = { id: created.id, secret: created.secret };
    saveOrderRef({ fileName: S.file.name, fileSize: S.file.size });
    if (S.tsWidget != null) { window.turnstile?.reset(S.tsWidget); S.tsToken = null; }

    const total = clip.blob.size + full.blob.size;
    await uploadBlob('preview', clip.blob, clip.ext, (p) => { steps[1].pct = (p * clip.blob.size) / total; draw(); });
    await uploadBlob('audio', full.blob, full.ext, (p) => { steps[1].pct = (clip.blob.size + p * full.blob.size) / total; draw(); });
    steps[1].state = 'done'; steps[1].pct = null; steps[2].state = 'active'; draw();

    await api(`/api/orders/${S.order.id}/preview`, { method: 'POST' });
    let v;
    do { await sleep(2500); v = await api(`/api/orders/${S.order.id}`); } while (v.status === 'previewing');
    if (v.status !== 'preview_ready') throw new Error(v.error || 'The preview didn\u2019t work.');
    steps[2].state = 'done'; draw();
    S.view = v;
    work.hidden = true;
    showPreview(v);
  } catch (e) {
    const i = steps.findIndex((s) => s.state === 'active');
    if (i >= 0) steps[i].state = 'failed';
    draw();
    err.textContent = e.message || 'Something went wrong. Please try again.';
    err.hidden = false;
    $('#work-retry').hidden = false;
    lockTool(false);
  }
}

// ── Preview player: the original picture with the dubbed sound in sync ──────
let listenMode = 'dub';
function wirePreview() {
  const v = $('#pv-video'), a = $('#pv-audio');
  const limit = () => S.cfg.previewSeconds;
  const resync = () => { if (listenMode === 'dub' && Math.abs(a.currentTime - v.currentTime) > 0.25) a.currentTime = v.currentTime; };
  v.addEventListener('play', () => { if (listenMode === 'dub') { a.currentTime = v.currentTime; a.play().catch(() => {}); } });
  v.addEventListener('pause', () => a.pause());
  v.addEventListener('seeking', () => { a.currentTime = Math.min(v.currentTime, limit()); });
  v.addEventListener('timeupdate', () => {
    if (v.currentTime >= limit()) { v.pause(); v.currentTime = 0; }
    resync();
  });
  for (const chip of document.querySelectorAll('.listen .chip')) {
    chip.addEventListener('click', () => {
      listenMode = chip.dataset.mode;
      for (const c of document.querySelectorAll('.listen .chip')) {
        const on = c === chip;
        c.classList.toggle('is-on', on);
        c.setAttribute('aria-checked', String(on));
      }
      if (listenMode === 'dub') { v.muted = true; if (!v.paused) { a.currentTime = v.currentTime; a.play().catch(() => {}); } }
      else { a.pause(); v.muted = false; }
    });
  }
  $('#pay').addEventListener('click', pay);
}

function showPreview(v) {
  $('#dub').hidden = true;
  const panel = $('#preview');
  panel.hidden = false;
  const video = $('#pv-video'), audio = $('#pv-audio');
  audio.src = v.previewAudio;
  if (S.file) {
    if (video.dataset.src) URL.revokeObjectURL(video.dataset.src);
    video.dataset.src = URL.createObjectURL(S.file);
    video.src = video.dataset.src;
    video.muted = listenMode === 'dub';
    video.hidden = false; $('#pv-resume').hidden = true;
    audio.controls = false;
  } else {
    video.hidden = true; $('#pv-resume').hidden = false;
    audio.controls = true;
  }
  const names = v.targets.map(nameOf);
  $('#pv-caption').textContent = `The first ${S.cfg.previewSeconds} seconds in ${names[0]}. `
    + `Your full video will be dubbed into ${joinNames(names)}${v.lipsync ? ', with lip matching' : ''}.`;

  const q = v.quote;
  const rows = [[`Dubbing, ${q.minutes} min into ${names.length} language${names.length > 1 ? 's' : ''}`, money(q.dubCents)]];
  if (q.lipsyncCents) rows.push(['Lip matching', money(q.lipsyncCents)]);
  rows.push(['Total', money(v.priceCents)]);
  const bill = $('#bill');
  bill.innerHTML = '';
  rows.forEach(([k, val], i) => {
    const row = document.createElement('div');
    row.className = 'bill-row' + (i === rows.length - 1 ? ' total' : '');
    row.innerHTML = '<span></span><span></span>';
    row.children[0].textContent = k; row.children[1].textContent = val;
    bill.append(row);
  });
  $('#pay').textContent = `Pay ${money(v.priceCents)} and dub the full video`;
  panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Checkout (Stripe's form in a dialog, so the video stays loaded) ──────────
function wireCheckout() {
  const dlg = $('#checkout-dialog');
  $('#checkout-close').addEventListener('click', closeCheckout);
  dlg.addEventListener('cancel', (e) => { e.preventDefault(); closeCheckout(); });
}
async function pay() {
  const btn = $('#pay');
  btn.disabled = true;
  try {
    await loadScript('https://js.stripe.com/v3/');
    const { clientSecret } = await api(`/api/orders/${S.order.id}/checkout`, { method: 'POST' });
    const stripe = window.Stripe(S.cfg.stripePublishableKey);
    S.checkout?.destroy();
    S.checkout = await stripe.initEmbeddedCheckout({ fetchClientSecret: async () => clientSecret, onComplete: onPaid });
    $('#checkout-dialog').showModal();
    S.checkout.mount('#checkout');
  } catch (e) {
    alert(e.message || 'Checkout couldn\u2019t open. Please try again.');
  } finally {
    btn.disabled = false;
  }
}
function closeCheckout() {
  S.checkout?.destroy();
  S.checkout = null;
  $('#checkout-dialog').close();
}
function onPaid() {
  closeCheckout();
  $('#preview').hidden = true;
  $('#pv-audio').pause(); $('#pv-video').pause();
  startProduction();
}

// ── After payment ────────────────────────────────────────────────────────────
function startProduction() {
  $('#dub').hidden = true; $('#work').hidden = true; $('#preview').hidden = true;
  const panel = $('#produce');
  panel.hidden = false;
  const link = `${location.origin}/#o=${S.order.id}.${S.order.secret}`;
  $('#order-link').value = link;
  $('#keep-link').hidden = false;
  panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  produceLoop();
}

async function produceLoop() {
  if (S.producing) return;
  S.producing = true;
  const err = $('#produce-error');
  for (;;) {
    let v;
    try { v = await api(`/api/orders/${S.order.id}`); err.hidden = true; }
    catch (e) {
      if (e.status === 404) { err.textContent = 'This order has expired.'; err.hidden = false; clearOrderRef(); break; }
      err.textContent = 'Having trouble reaching Ultradub. Retrying\u2026'; err.hidden = false;
      await sleep(5000); continue;
    }
    S.view = v;
    renderProduction(v);
    if (v.lipsync && S.file) lipsyncUploads(v);   // runs in the background
    if (['ready', 'failed', 'expired'].includes(v.status)) break;
    await sleep(4000);
  }
  S.producing = false;
}

const uploadState = {};
function renderProduction(v) {
  const title = $('#produce-title'), hint = $('#produce-hint');
  const steps = [];
  for (const l of v.langs) {
    const name = nameOf(l.lang);
    steps.push({
      label: { done: `${name} dub ready`, failed: `${name} didn\u2019t work (refunded)` }[l.status] || `Dubbing into ${name}`,
      state: l.status === 'done' ? 'done' : l.status === 'failed' ? 'failed' : 'active',
    });
  }
  if (v.lipsync) {
    const u = uploadState.video;
    if (u) steps.push({ label: u.done ? 'Video uploaded for lip matching' : 'Uploading your video for lip matching', state: u.done ? 'done' : 'active', pct: u.done ? null : u.pct });
    for (const l of v.langs) {
      if (!l.lipsync || l.status === 'failed') continue;
      const s = l.lipsync.status;
      steps.push({
        label: { done: `Lips matched in ${nameOf(l.lang)}`, failed: `Lip matching in ${nameOf(l.lang)} didn\u2019t work (refunded)` }[s] || `Matching lip movements in ${nameOf(l.lang)}`,
        state: s === 'done' ? 'done' : s === 'failed' ? 'failed' : (l.status === 'done' ? 'active' : ''),
      });
    }
  }
  renderSteps($('#produce-steps'), steps);

  const notes = $('#notes');
  notes.innerHTML = '';
  for (const n of v.notes) { const p = document.createElement('p'); p.className = 'note'; p.textContent = n; notes.append(p); }

  if (v.status === 'failed') {
    title.textContent = 'We couldn\u2019t dub this video';
    hint.textContent = v.error || 'You\u2019ve been refunded in full.';
    return;
  }
  if (v.status === 'expired') { title.textContent = 'This order has expired'; hint.textContent = 'Files are kept for 48 hours.'; return; }
  if (v.status !== 'ready') {
    title.textContent = 'Dubbing your full video';
    hint.textContent = v.lipsync && !S.file
      ? 'Pick your video again below so lip matching can start.'
      : 'This usually takes a few minutes. Keep this tab open.';
    $('#resume').hidden = !(v.lipsync && !S.file && v.needs.video);
    return;
  }
  title.textContent = 'Your videos are ready';
  hint.textContent = 'Save each version below. Your order is kept for 48 hours.';
  $('#resume').hidden = !!S.file;
  renderDownloads(v);
}

function renderDownloads(v) {
  const box = $('#downloads');
  if (box.dataset.for === v.id + v.status) return;
  box.dataset.for = v.id + v.status;
  box.innerHTML = '';
  for (const l of v.langs.filter((x) => x.status === 'done')) {
    const lang = langById(l.lang);
    const card = document.createElement('div');
    card.className = 'dl';
    card.innerHTML = `
      <div class="dl-head"><span class="dl-name"></span><span class="dl-native"></span></div>
      <div class="dl-actions"><button class="btn btn-primary" data-save></button></div>
      <div class="bar" hidden><i></i></div>
      <p class="hint" data-msg hidden></p>`;
    card.querySelector('.dl-name').textContent = lang.name;
    card.querySelector('.dl-native').textContent = lang.native !== lang.name ? lang.native : '';
    const saveBtn = card.querySelector('[data-save]');
    saveBtn.textContent = l.lipsync?.video ? 'Save with original lips' : 'Save video';
    if (l.lipsync?.video) saveBtn.className = 'btn btn-secondary';
    saveBtn.disabled = !S.file;
    saveBtn.addEventListener('click', () => saveLanguage(l.lang, card));
    if (l.lipsync?.video) {
      const a = document.createElement('a');
      a.className = 'btn btn-primary';
      a.href = l.lipsync.video;
      a.download = `${baseName(S.file?.name)}-${l.lang}-lipsync.mp4`;
      a.textContent = 'Save lip-matched video';
      card.querySelector('.dl-actions').prepend(a);
    }
    box.append(card);
  }
}

async function saveLanguage(lang, card) {
  const btn = card.querySelector('[data-save]'), bar = card.querySelector('.bar'), msg = card.querySelector('[data-msg]');
  const name = `${baseName(S.file.name)}-${lang}.mp4`;
  let sink = 'memory', writable = null;
  if (window.showSaveFilePicker) {
    try {
      const handle = await window.showSaveFilePicker({ suggestedName: name, types: [{ description: 'MP4 video', accept: { 'video/mp4': ['.mp4'] } }] });
      writable = await handle.createWritable();
      sink = new WritableStream({
        write: (c) => writable.write({ type: 'write', position: c.position, data: c.data }),
        close: () => writable.close(),
        abort: (r) => writable.abort(r),
      });
    } catch (e) {
      if (e.name === 'AbortError') return;
      writable = null; sink = 'memory';
    }
  }
  btn.disabled = true;
  bar.hidden = false; msg.hidden = false; msg.textContent = 'Putting your video together\u2026';
  try {
    const fresh = await api(`/api/orders/${S.order.id}`);   // signed links expire, so get a fresh one
    const url = fresh.langs.find((x) => x.lang === lang).audio;
    const blob = await exportDubbedVideo({
      videoFile: S.file, dubSource: url, sink,
      onProgress: (p) => { bar.firstElementChild.style.width = `${Math.round(p * 100)}%`; },
    });
    if (blob) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = name;
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60_000);
    }
    msg.textContent = `Saved as ${name}.`;
  } catch (e) {
    console.error(e);
    msg.textContent = S.file.size > 1.5e9 && !window.showSaveFilePicker
      ? 'This video is too large to save on this device. Open your order link on a computer using Chrome or Edge.'
      : 'Saving didn\u2019t work. Please try again.';
  } finally {
    btn.disabled = false;
  }
}

// Lip sync needs the actual video (as MP4) and each dub as WAV.
async function lipsyncUploads(v) {
  if (v.needs.video && !S.uploading.has('video')) {
    S.uploading.add('video');
    uploadState.video = { pct: 0, done: false };
    (async () => {
      try {
        const isMp4 = /\.(mp4|m4v)$/i.test(S.file.name) || S.file.type === 'video/mp4';
        if (isMp4) await uploadBlob('video', S.file, 'mp4', (p) => { uploadState.video.pct = p; });
        else {
          let written = 0;
          await uploadProduced('video', 'mp4', (onBytes) => streamVideoAsMp4(S.file, async (data) => {
            await onBytes(data); written += data.length; uploadState.video.pct = Math.min(0.99, written / S.file.size);
          }));
        }
        uploadState.video.done = true;
      } catch (e) {
        console.error(e);
        S.uploading.delete('video');   // try again on the next poll
      }
    })();
  }
  for (const lang of v.needs.wav) {
    const key = `wav-${lang}`;
    if (S.uploading.has(key)) continue;
    S.uploading.add(key);
    (async () => {
      try {
        const l = v.langs.find((x) => x.lang === lang);
        const wav = await flacToWav(l.audio);
        await uploadBlob(`lips-${lang}`, wav, 'wav');
      } catch (e) {
        console.error(e);
        S.uploading.delete(key);
      }
    })();
  }
}

// ── Coming back to an order ──────────────────────────────────────────────────
async function resumeIfAny() {
  const m = location.hash.match(/^#o=([a-f0-9]{24})\.([a-f0-9]{48})$/);
  const stored = JSON.parse(localStorage.getItem(STORE) || 'null');
  const ref = m ? { id: m[1], secret: m[2] } : stored;
  if (!ref?.id) return;
  S.order = { id: ref.id, secret: ref.secret };
  let v;
  try { v = await api(`/api/orders/${ref.id}`); } catch { S.order = null; clearOrderRef(); return; }
  if (m) saveOrderRef();
  S.view = v;
  if (['created', 'expired', 'preview_failed'].includes(v.status)) { S.order = null; clearOrderRef(); return; }
  S.source = v.source; S.targets = [...v.targets]; S.lipsync = v.lipsync;
  $('#source').value = S.source;
  if (v.status === 'previewing' || v.status === 'preview_ready') {
    if (v.status === 'previewing') {
      do { await sleep(2500); v = await api(`/api/orders/${ref.id}`); } while (v.status === 'previewing');
      if (v.status !== 'preview_ready') { S.order = null; clearOrderRef(); return; }
    }
    showPreview(v);
    return;
  }
  startProduction();
}

async function onRepick(file) {
  const v = S.view;
  try {
    const info = await probeVideo(file);
    if (v && Math.abs(info.duration - v.duration) > 2) {
      alert('That doesn\u2019t look like the same video (it\u2019s a different length). Pick the video you dubbed.');
      return;
    }
    S.file = file; S.info = info;
  } catch {
    alert('We can\u2019t read that file. Pick the video you dubbed.');
    return;
  }
  if (!$('#preview').hidden) { showPreview(v); return; }
  $('#resume').hidden = true;
  $('#downloads').dataset.for = '';
  if (v.status === 'ready') renderProduction(v); else produceLoop();
}

function startOver() {
  S.order = null; S.view = null; clearOrderRef();
  if (location.hash) history.replaceState(null, '', location.pathname);
  $('#work').hidden = true; $('#preview').hidden = true; $('#produce').hidden = true;
  $('#dub').hidden = false;
  lockTool(false);
  $('#dub').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

init();

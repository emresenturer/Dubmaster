// Ultradub media helpers, built on Mediabunny.
// Everything here runs in the customer's browser: the video file never leaves their device
// unless lip sync is ordered. Heavy work is stream-based so long 4K files stay out of memory.

import {
  Input, Output, ALL_FORMATS, BlobSource, UrlSource, BufferTarget, StreamTarget,
  Mp4OutputFormat, Mp3OutputFormat, OggOutputFormat, WavOutputFormat, FlacOutputFormat,
  Conversion, EncodedPacketSink, EncodedVideoPacketSource, AudioSampleSink, AudioSampleSource,
  AudioSample, CustomAudioDecoder, registerDecoder, canEncodeAudio, canDecodeAudio,
} from 'mediabunny';

// Environment-specific loaders are injected so the same module runs in browsers and in tests.
const hooks = {
  loadAacEncoder: null,        // async () => registers an AAC encoder with Mediabunny
  loadFlacDecoderClass: null,  // async () => FLACDecoder class (wasm-audio-decoders API)
};
export function configureMedia(options) { Object.assign(hooks, options); }

const AUDIO_OUT = {
  aac:    { make: () => new Mp4OutputFormat({ fastStart: 'in-memory' }), ext: 'm4a', mime: 'audio/mp4' },
  mp3:    { make: () => new Mp3OutputFormat(), ext: 'mp3', mime: 'audio/mpeg' },
  opus:   { make: () => new OggOutputFormat(), ext: 'ogg', mime: 'audio/ogg' },
  vorbis: { make: () => new OggOutputFormat(), ext: 'ogg', mime: 'audio/ogg' },
  flac:   { make: () => new FlacOutputFormat(), ext: 'flac', mime: 'audio/flac' },
};

function openInput(source) {
  const src = typeof source === 'string' ? new UrlSource(source) : new BlobSource(source);
  return new Input({ source: src, formats: ALL_FORMATS });
}

// ── Probe ─────────────────────────────────────────────────────────────────────
export async function probeVideo(file) {
  const input = openInput(file);
  try {
    if (!(await input.canRead())) throw new MediaError('unreadable');
    const video = await input.getPrimaryVideoTrack();
    const audio = await input.getPrimaryAudioTrack();
    if (!video) throw new MediaError('no_video');
    if (!audio) throw new MediaError('no_audio');
    const duration = await input.computeDuration();
    return {
      duration,
      videoCodec: video.codec,
      audioCodec: audio.codec,
      width: video.displayWidth,
      height: video.displayHeight,
      rotation: video.rotation,
      mime: await input.getMimeType(),
    };
  } finally {
    input.dispose();
  }
}

export class MediaError extends Error {
  constructor(code, detail) { super(detail || code); this.code = code; }
}

// ── Codec fallbacks ───────────────────────────────────────────────────────────
let aacReady = null;
export function ensureAacEncoding() {
  aacReady ??= (async () => {
    const native = await canEncodeAudio('aac', { numberOfChannels: 2, sampleRate: 48000, bitrate: 192_000 });
    if (!native) {
      if (!hooks.loadAacEncoder) throw new MediaError('no_aac_encoder');
      await hooks.loadAacEncoder();
    }
  })();
  return aacReady;
}

let flacReady = null;
export function ensureFlacDecoding() {
  flacReady ??= (async () => {
    const native = await canDecodeAudio('flac', { numberOfChannels: 2, sampleRate: 48000 });
    if (native) return;
    if (!hooks.loadFlacDecoderClass) throw new MediaError('no_flac_decoder');
    const FLACDecoder = await hooks.loadFlacDecoderClass();

    class WasmFlacDecoder extends CustomAudioDecoder {
      static supports(codec) { return codec === 'flac'; }
      async init() { this.dec = new FLACDecoder(); await this.dec.ready; }
      async decode(packet) {
        const out = await this.dec.decodeFrames([packet.data]);
        const n = out.samplesDecoded;
        if (!n) return;
        const ch = out.channelData.length;
        const planar = new Float32Array(ch * n);
        for (let c = 0; c < ch; c++) planar.set(out.channelData[c].subarray(0, n), c * n);
        this.onSample(new AudioSample({
          data: planar, format: 'f32-planar', numberOfChannels: ch,
          sampleRate: out.sampleRate, timestamp: packet.timestamp,
        }));
      }
      async flush() {}
      async close() { this.dec?.free(); }
    }
    registerDecoder(WasmFlacDecoder);
  })();
  return flacReady;
}

// ── Audio extraction (upload only the sound) ─────────────────────────────────
// Copies the audio track out of the video without re-encoding when possible.
export async function extractAudio(file, { start, end, onProgress } = {}) {
  const input = openInput(file);
  try {
    const track = await input.getPrimaryAudioTrack();
    if (!track) throw new MediaError('no_audio');
    let spec = AUDIO_OUT[track.codec];
    if (!spec) { await ensureAacEncoding(); spec = AUDIO_OUT.aac; }

    const target = new BufferTarget();
    const output = new Output({ format: spec.make(), target });
    const trim = (start != null || end != null) ? { start: start ?? 0, end } : undefined;
    const conversion = await Conversion.init({
      input, output, trim,
      video: { discard: true },
      audio: AUDIO_OUT[track.codec] ? {} : { codec: 'aac', bitrate: 192_000 },
      showWarnings: false,
    });
    if (!conversion.isValid) {
      const why = conversion.discardedTracks.map((d) => d.reason).join(', ');
      throw new MediaError('audio_extract_failed', why);
    }
    if (onProgress) conversion.onProgress = onProgress;
    await conversion.execute();
    return { blob: new Blob([target.buffer], { type: spec.mime }), ext: spec.ext, mime: spec.mime };
  } finally {
    input.dispose();
  }
}

// ── Final video: original picture + dubbed audio ─────────────────────────────
// The picture is copied packet by packet, so quality and resolution are untouched.
// The dub (FLAC from the server) is encoded to AAC for universal playback.
// `sink` is either 'memory' (returns a Blob) or a WritableStream of StreamTarget chunks.
export async function exportDubbedVideo({ videoFile, dubSource, sink = 'memory', onProgress }) {
  await ensureFlacDecoding();
  await ensureAacEncoding();

  const vIn = openInput(videoFile);
  const aIn = openInput(dubSource);
  try {
    const vTrack = await vIn.getPrimaryVideoTrack();
    const aTrack = await aIn.getPrimaryAudioTrack();
    if (!vTrack) throw new MediaError('no_video');
    if (!aTrack) throw new MediaError('no_dub_audio');
    const total = await vIn.computeDuration([vTrack]);

    const inMemory = sink === 'memory';
    const target = inMemory ? new BufferTarget() : new StreamTarget(sink, { chunked: true });
    const output = new Output({
      format: new Mp4OutputFormat({ fastStart: inMemory ? 'in-memory' : false }),
      target,
    });

    const vSource = new EncodedVideoPacketSource(vTrack.codec);
    output.addVideoTrack(vSource, { rotation: vTrack.rotation });
    const aSource = new AudioSampleSource({ codec: 'aac', bitrate: 192_000 });
    output.addAudioTrack(aSource);
    await output.start();

    const decoderConfig = await vTrack.getDecoderConfig();
    let videoDone = 0, audioDone = 0;
    const report = () => onProgress?.(Math.min(1, (videoDone + audioDone) / (2 * (total || 1))));

    const copyVideo = (async () => {
      const sink = new EncodedPacketSink(vTrack);
      let first = true;
      for await (const packet of sink.packets()) {
        await vSource.add(packet, first ? { decoderConfig } : undefined);
        first = false;
        videoDone = packet.timestamp + packet.duration;
        report();
      }
      vSource.close();
    })();

    const encodeAudio = (async () => {
      const sink = new AudioSampleSink(aTrack);
      for await (const sample of sink.samples()) {
        if (sample.timestamp >= total) { sample.close(); break; }
        await aSource.add(sample);
        audioDone = sample.timestamp + sample.duration;
        sample.close();
        report();
      }
      aSource.close();
    })();

    await Promise.all([copyVideo, encodeAudio]);
    await output.finalize();
    onProgress?.(1);
    return inMemory ? new Blob([target.buffer], { type: 'video/mp4' }) : null;
  } finally {
    vIn.dispose();
    aIn.dispose();
  }
}

// ── Lip sync helpers ─────────────────────────────────────────────────────────
// sync.so accepts WAV or MP3 audio, so the FLAC dub is converted to 16-bit WAV.
export async function flacToWav(dubSource) {
  await ensureFlacDecoding();
  const input = openInput(dubSource);
  try {
    const target = new BufferTarget();
    const output = new Output({ format: new WavOutputFormat(), target });
    const conversion = await Conversion.init({
      input, output, audio: { codec: 'pcm-s16' }, showWarnings: false,
    });
    if (!conversion.isValid) throw new MediaError('wav_failed');
    await conversion.execute();
    return new Blob([target.buffer], { type: 'audio/wav' });
  } finally {
    input.dispose();
  }
}

// sync.so wants MP4 video. MP4 uploads go as-is; anything else (for example iPhone MOV)
// is re-wrapped into MP4 without re-encoding and streamed out in order via `onBytes`.
export async function streamVideoAsMp4(file, onBytes, { onProgress } = {}) {
  const input = openInput(file);
  try {
    const target = new StreamTarget(new WritableStream({
      async write(chunk) { await onBytes(chunk.data, chunk.position); },
    }), { chunked: true, chunkSize: 4 * 1024 * 1024 });
    const output = new Output({ format: new Mp4OutputFormat({ fastStart: 'fragmented' }), target });
    const conversion = await Conversion.init({ input, output, showWarnings: false });
    if (!conversion.isValid) throw new MediaError('remux_failed');
    if (onProgress) conversion.onProgress = onProgress;
    await conversion.execute();
  } finally {
    input.dispose();
  }
}

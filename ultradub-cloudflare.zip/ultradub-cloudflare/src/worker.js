// Ultradub API. Runs on Cloudflare Workers with R2 (files) and D1 (orders).
//
// Flow
//   1. Browser creates an order, uploads a 20-second audio clip and the full audio track.
//   2. /preview dubs only the clip, so a free preview costs cents.
//   3. Customer pays in an embedded Stripe checkout. Stripe's webhook (or the next poll) marks it paid.
//   4. The full audio is dubbed into every language. Outputs are copied into R2.
//   5. Optional lip sync: the browser uploads the video and a WAV per language; sync.so does the rest.
//   6. Anything that fails after payment is refunded automatically, per language.
//
// Every external job is advanced by `advance()`, called from browser polling and from a 1-minute cron,
// guarded by a row lock so two callers never start the same job twice.

import { Input, ALL_FORMATS, CustomSource } from 'mediabunny';

// ── Languages ────────────────────────────────────────────────────────────────
// Bengali is only on ElevenLabs' v1 model; everything else uses Dubbing v2.
const LANGS = {
  en:  { name: 'English',            native: 'English',          code: 'en' },
  zh:  { name: 'Chinese (Mandarin)', native: '中文',              code: 'zh' },
  hi:  { name: 'Hindi',              native: 'हिन्दी',             code: 'hi' },
  es:  { name: 'Spanish',            native: 'Español',          code: 'es' },
  ar:  { name: 'Arabic',             native: 'العربية',           code: 'ar' },
  fr:  { name: 'French',             native: 'Français',         code: 'fr' },
  bn:  { name: 'Bengali',            native: 'বাংলা',             code: 'bn', v1Only: true },
  pt:  { name: 'Portuguese',         native: 'Português',        code: 'pt-BR' },
  ru:  { name: 'Russian',            native: 'Русский',          code: 'ru' },
  id:  { name: 'Indonesian',         native: 'Bahasa Indonesia', code: 'id' },
  ur:  { name: 'Urdu',               native: 'اردو',              code: 'ur' },
  de:  { name: 'German',             native: 'Deutsch',          code: 'de' },
  ja:  { name: 'Japanese',           native: '日本語',            code: 'ja' },
  mr:  { name: 'Marathi',            native: 'मराठी',              code: 'mr' },
  vi:  { name: 'Vietnamese',         native: 'Tiếng Việt',       code: 'vi' },
  te:  { name: 'Telugu',             native: 'తెలుగు',             code: 'te' },
  tr:  { name: 'Turkish',            native: 'Türkçe',           code: 'tr' },
  ta:  { name: 'Tamil',              native: 'தமிழ்',              code: 'ta' },
  ko:  { name: 'Korean',             native: '한국어',             code: 'ko' },
  fil: { name: 'Filipino',           native: 'Filipino',         code: 'fil' },
};

const modelFor = (source, target) =>
  (LANGS[source]?.v1Only || LANGS[target]?.v1Only) ? 'dubbing_v1' : 'dubbing_v2';
// v1 has no regional dialects, so strip the region there.
const elCode = (lang, model) => model === 'dubbing_v1' ? LANGS[lang].code.split('-')[0] : LANGS[lang].code;

// ── Settings ─────────────────────────────────────────────────────────────────
const num = (v, d) => (v === undefined || v === null || v === '' || isNaN(Number(v))) ? d : Number(v);
const settings = (env) => ({
  perMin: num(env.PRICE_PER_MIN_CENTS, 150),
  minPrice: num(env.MIN_PRICE_CENTS, 599),
  lipPerMin: num(env.LIPSYNC_PER_MIN_CENTS, 800),
  maxMinutes: num(env.MAX_MINUTES, 60),
  lipMaxMinutes: num(env.LIPSYNC_MAX_MINUTES, 5),
  previewSeconds: num(env.PREVIEW_SECONDS, 20),
  maxTargets: num(env.MAX_TARGETS, 3),
  ordersPerHour: num(env.ORDERS_PER_IP_PER_HOUR, 6),
  keepHours: num(env.KEEP_HOURS, 48),
  lipsyncEnabled: !!env.SYNC_API_KEY,
  lipsyncModel: env.LIPSYNC_MODEL || 'lipsync-2-pro',
});

export function quote(env, seconds, nLangs, lipsync) {
  const s = settings(env);
  const minutes = Math.max(1, Math.ceil(seconds / 60));
  const dubCents = Math.max(s.minPrice, minutes * s.perMin * nLangs);
  const lipsyncCents = lipsync ? minutes * s.lipPerMin * nLangs : 0;
  return { minutes, dubCents, lipsyncCents, totalCents: dubCents + lipsyncCents };
}

// ── Small helpers ────────────────────────────────────────────────────────────
const json = (body, status = 200, headers = {}) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...headers } });
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const bad = (msg) => { throw new HttpError(400, msg); };

const enc = new TextEncoder();
const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const randomHex = (bytes) => toHex(crypto.getRandomValues(new Uint8Array(bytes)));
const sha256 = async (text) => toHex(await crypto.subtle.digest('SHA-256', enc.encode(text)));
async function hmac(secret, message, out = 'hex') {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
  return out === 'hex' ? toHex(sig) : b64url(sig);
}
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
const errorText = (e) => (e && (e.message || e.code || JSON.stringify(e))) || 'unknown error';

// ── Signed media URLs (R2 objects served by this Worker) ─────────────────────
async function mediaUrl(env, origin, key, ttlSeconds = 6 * 3600) {
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;
  const sig = await hmac(env.MEDIA_SIGNING_SECRET, `${key}.${exp}`, 'b64');
  return `${origin}/api/media/${key}?e=${exp}&s=${sig}`;
}

async function serveMedia(env, request, key, url) {
  const exp = Number(url.searchParams.get('e'));
  const sig = url.searchParams.get('s') || '';
  if (!exp || exp < Date.now() / 1000) throw new HttpError(403, 'Link expired');
  if (!safeEqual(sig, await hmac(env.MEDIA_SIGNING_SECRET, `${key}.${exp}`, 'b64'))) throw new HttpError(403, 'Bad signature');

  const head = await env.MEDIA.head(key);
  if (!head) throw new HttpError(404, 'Not found');
  const size = head.size;
  const type = head.httpMetadata?.contentType || 'application/octet-stream';
  const base = { 'content-type': type, 'accept-ranges': 'bytes', 'cache-control': 'private, max-age=3600', 'access-control-allow-origin': '*' };
  if (request.method === 'HEAD') return new Response(null, { headers: { ...base, 'content-length': String(size) } });

  const m = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get('range') || '');
  if (m && (m[1] || m[2])) {
    let start, end;
    if (m[1] === '') { const n = Number(m[2]); start = Math.max(0, size - n); end = size - 1; }
    else { start = Number(m[1]); end = m[2] === '' ? size - 1 : Math.min(Number(m[2]), size - 1); }
    if (start > end || start >= size) return new Response(null, { status: 416, headers: { ...base, 'content-range': `bytes */${size}` } });
    const obj = await env.MEDIA.get(key, { range: { offset: start, length: end - start + 1 } });
    return new Response(obj.body, { status: 206, headers: { ...base, 'content-length': String(end - start + 1), 'content-range': `bytes ${start}-${end}/${size}` } });
  }
  const obj = await env.MEDIA.get(key);
  return new Response(obj.body, { headers: { ...base, 'content-length': String(size) } });
}

// Copy a remote file (a signed ElevenLabs or sync.so URL) into R2 without buffering it all.
async function copyToR2(env, url, key, contentType) {
  const r = await fetch(url);
  if (!r.ok || !r.body) throw new Error(`download failed (${r.status})`);
  const len = Number(r.headers.get('content-length'));
  const meta = { httpMetadata: { contentType } };
  if (len > 0) {
    const { readable, writable } = new FixedLengthStream(len);
    await Promise.all([r.body.pipeTo(writable), env.MEDIA.put(key, readable, meta)]);
  } else {
    await env.MEDIA.put(key, await r.arrayBuffer(), meta);
  }
}

// Duration of an uploaded file, read straight from R2 (only the byte ranges it needs).
async function r2Duration(env, key) {
  const head = await env.MEDIA.head(key);
  if (!head) throw new Error('missing upload');
  const input = new Input({
    formats: ALL_FORMATS,
    source: new CustomSource({
      getSize: () => head.size,
      read: async (start, end) => {
        const obj = await env.MEDIA.get(key, { range: { offset: start, length: end - start } });
        return new Uint8Array(await obj.arrayBuffer());
      },
    }),
  });
  try { return await input.computeDuration(); } finally { input.dispose(); }
}

// ── External APIs ────────────────────────────────────────────────────────────
async function callJson(url, init, label) {
  const r = await fetch(url, init);
  const text = await r.text();
  let body; try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text.slice(0, 300) }; }
  if (!r.ok) {
    const msg = body?.error?.message || body?.detail?.message || body?.detail || body?.message || body?.raw || r.statusText;
    const err = new Error(`${label} ${r.status}: ${typeof msg === 'string' ? msg : JSON.stringify(msg)}`);
    err.status = r.status;
    throw err;
  }
  return body;
}

const el = {
  base: (env) => env.ELEVENLABS_API_BASE || 'https://api.elevenlabs.io',
  headers: (env) => ({ 'xi-api-key': env.ELEVENLABS_API_KEY }),
  createProject(env, { sourceUrl, source, target, model, reference }) {
    const form = new FormData();
    form.append('source_url', sourceUrl);
    form.append('source_language', LANGS[source].code.split('-')[0]);
    form.append('target_language', elCode(target, model));
    form.append('model_id', model);
    form.append('reference', reference);
    return callJson(`${el.base(env)}/v1/dubbing/project`, { method: 'POST', headers: el.headers(env), body: form }, 'ElevenLabs');
  },
  getProject: (env, id) =>
    callJson(`${el.base(env)}/v1/dubbing/project/${id}`, { headers: el.headers(env) }, 'ElevenLabs'),
  addLanguage: (env, projectId, target, model) =>
    callJson(`${el.base(env)}/v1/dubbing/project/${projectId}/language`, {
      method: 'POST', headers: { ...el.headers(env), 'content-type': 'application/json' },
      body: JSON.stringify({ target_language: elCode(target, model) }),
    }, 'ElevenLabs'),
  getLanguage: (env, projectId, languageId) =>
    callJson(`${el.base(env)}/v1/dubbing/project/${projectId}/language/${languageId}`, { headers: el.headers(env) }, 'ElevenLabs'),
};

const lips = {
  base: (env) => env.SYNC_API_BASE || 'https://api.sync.so',
  create: (env, videoUrl, audioUrl) =>
    callJson(`${lips.base(env)}/v2/generate`, {
      method: 'POST', headers: { 'x-api-key': env.SYNC_API_KEY, 'content-type': 'application/json' },
      body: JSON.stringify({
        model: settings(env).lipsyncModel,
        input: [{ type: 'video', url: videoUrl }, { type: 'audio', url: audioUrl }],
        options: { sync_mode: 'cut_off' },
      }),
    }, 'sync.so'),
  get: (env, id) => callJson(`${lips.base(env)}/v2/generate/${id}`, { headers: { 'x-api-key': env.SYNC_API_KEY } }, 'sync.so'),
};

function formEncode(obj, prefix, out = new URLSearchParams()) {
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null) continue;
    const key = prefix ? `${prefix}[${k}]` : k;
    if (typeof v === 'object') formEncode(v, key, out); else out.append(key, String(v));
  }
  return out;
}
const stripe = {
  base: (env) => env.STRIPE_API_BASE || 'https://api.stripe.com',
  call(env, method, path, params, idempotencyKey) {
    const headers = { authorization: `Bearer ${env.STRIPE_SECRET_KEY}`, 'stripe-version': '2024-06-20' };
    let body;
    if (params) { headers['content-type'] = 'application/x-www-form-urlencoded'; body = formEncode(params).toString(); }
    if (idempotencyKey) headers['idempotency-key'] = idempotencyKey;
    return callJson(`${stripe.base(env)}/v1${path}`, { method, headers, body }, 'Stripe');
  },
};

async function verifyStripeSignature(env, payload, header) {
  const parts = Object.fromEntries((header || '').split(',').map((p) => p.split('=')).filter((p) => p.length === 2).map(([k, v]) => [k.trim(), v]));
  const signatures = (header || '').split(',').filter((p) => p.startsWith('v1=')).map((p) => p.slice(3));
  const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > 300) return false;
  const expected = await hmac(env.STRIPE_WEBHOOK_SECRET, `${t}.${payload}`);
  return signatures.some((s) => safeEqual(s, expected));
}

async function verifyTurnstile(env, token, ip) {
  if (!env.TURNSTILE_SECRET_KEY) return true;
  if (!token) return false;
  const form = new FormData();
  form.append('secret', env.TURNSTILE_SECRET_KEY);
  form.append('response', token);
  if (ip) form.append('remoteip', ip);
  const r = await fetch(env.TURNSTILE_VERIFY_URL || 'https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form });
  const body = await r.json().catch(() => ({}));
  return !!body.success;
}

// ── Orders in D1 ─────────────────────────────────────────────────────────────
function parseRow(row) {
  if (!row) return null;
  return { ...row, targets: JSON.parse(row.targets), lipsync: !!row.lipsync, data: JSON.parse(row.data || '{}') };
}
async function loadOrder(env, id) {
  return parseRow(await env.DB.prepare('SELECT * FROM orders WHERE id = ?').bind(id).first());
}
async function saveOrder(env, o) {
  o.updated_at = Date.now();
  await env.DB.prepare('UPDATE orders SET status=?, duration=?, price_cents=?, data=?, updated_at=? WHERE id=?')
    .bind(o.status, o.duration ?? null, o.price_cents, JSON.stringify(o.data), o.updated_at, o.id).run();
}
async function authOrder(env, request, id) {
  const url = new URL(request.url);
  const secret = request.headers.get('x-order-secret') || url.searchParams.get('k') || '';
  const order = await loadOrder(env, id);
  if (!order || !secret || !safeEqual(order.secret_hash, await sha256(secret))) throw new HttpError(404, 'Order not found');
  return order;
}

// Run `fn` on a fresh copy of the order while holding its row lock.
async function withLock(env, id, fn) {
  const now = Date.now();
  const r = await env.DB.prepare('UPDATE orders SET lock_until = ? WHERE id = ? AND lock_until < ?').bind(now + 120_000, id, now).run();
  if (!r.meta.changes) return false;
  try {
    const order = await loadOrder(env, id);
    await fn(order);
  } finally {
    await env.DB.prepare('UPDATE orders SET lock_until = 0 WHERE id = ?').bind(id).run();
  }
  return true;
}

// ── Refunds ──────────────────────────────────────────────────────────────────
async function refund(env, order, cents, reason) {
  const d = order.data;
  const already = d.refundedCents || 0;
  const amount = Math.min(cents, order.price_cents - already);
  if (amount <= 0 || !d.paymentIntent) return;
  const r = await stripe.call(env, 'POST', '/refunds',
    { payment_intent: d.paymentIntent, amount, metadata: { order_id: order.id, reason } },
    `ultradub-${order.id}-${reason}`);
  d.refundedCents = already + amount;
  (d.refunds ||= []).push({ id: r.id, amount, reason });
}

// ── State machine ────────────────────────────────────────────────────────────
async function advance(env, origin, order, persist) {
  switch (order.status) {
    case 'previewing': return advancePreview(env, origin, order, persist);
    case 'preview_ready': return checkPayment(env, order, persist);
    case 'paid': return startFullDub(env, origin, order, persist);
    case 'dubbing': return advanceDubbing(env, origin, order, persist);
    case 'lipsync': return advanceLipsync(env, origin, order, persist);
  }
}

async function advancePreview(env, origin, order, persist) {
  const d = order.data;
  const target = order.targets[0];
  if (!d.preview) {
    const model = modelFor(order.source, target);
    const p = await el.createProject(env, {
      sourceUrl: await mediaUrl(env, origin, d.files.preview),
      source: order.source, target, model, reference: `ultradub ${order.id} preview`,
    });
    d.preview = { projectId: p.project_id, languageId: p.language_ids?.[0] || null, model };
    return persist();
  }
  if (!d.preview.languageId) {
    const p = await el.getProject(env, d.preview.projectId);
    if (p.status === 'failed') { order.status = 'preview_failed'; d.error = 'We couldn\u2019t hear clear speech in this clip.'; return persist(); }
    d.preview.languageId = p.language_ids?.[0] || null;
    if (!d.preview.languageId) d.preview.languageId = (await el.addLanguage(env, d.preview.projectId, target, d.preview.model)).language_id;
    return persist();
  }
  const lang = await el.getLanguage(env, d.preview.projectId, d.preview.languageId);
  if (lang.status === 'completed' && lang.outputs?.lossless_audio) {
    const key = `orders/${order.id}/preview-${target}.flac`;
    await copyToR2(env, lang.outputs.lossless_audio, key, 'audio/flac');
    d.files.previewDub = key;
    order.status = 'preview_ready';
    return persist();
  }
  if (lang.status === 'failed') {
    order.status = 'preview_failed';
    d.error = 'We couldn\u2019t dub this clip. Try a clip where the voice is clearer.';
    d.log = errorText(lang.error);
    return persist();
  }
}

async function checkPayment(env, order, persist) {
  const d = order.data;
  if (!d.sessionId) return;
  const s = await stripe.call(env, 'GET', `/checkout/sessions/${d.sessionId}`);
  if (s.payment_status === 'paid') { markPaid(order, s); return persist(); }
}

function markPaid(order, session) {
  if (order.status !== 'preview_ready') return false;
  order.status = 'paid';
  order.data.paymentIntent = session.payment_intent;
  order.data.paidAt = Date.now();
  return true;
}

async function startFullDub(env, origin, order, persist) {
  const d = order.data;
  d.groups ||= {};
  d.langs ||= {};
  const audioUrl = await mediaUrl(env, origin, d.files.audio, 24 * 3600);
  for (const target of order.targets) {
    const model = modelFor(order.source, target);
    const g = d.groups[model];
    if (!g) {
      const p = await el.createProject(env, {
        sourceUrl: audioUrl, source: order.source, target, model, reference: `ultradub ${order.id}`,
      });
      d.groups[model] = { projectId: p.project_id };
      d.langs[target] = { model, languageId: p.language_ids?.[0] || null, status: 'processing', attempts: 1 };
      await persist();   // save immediately: a created project costs money, never create it twice
    } else if (!d.langs[target]) {
      const l = await el.addLanguage(env, g.projectId, target, model);
      d.langs[target] = { model, languageId: l.language_id, status: 'processing', attempts: 1 };
      await persist();
    }
  }
  order.status = 'dubbing';
  return persist();
}

async function advanceDubbing(env, origin, order, persist) {
  const d = order.data;
  for (const target of order.targets) {
    const l = d.langs[target];
    if (!l || l.status === 'done' || l.status === 'failed') continue;
    const g = d.groups[l.model];
    if (!l.languageId) {
      const p = await el.getProject(env, g.projectId);
      if (p.status === 'failed') { l.status = 'failed'; l.reason = errorText(p.error); await persist(); continue; }
      l.languageId = p.language_ids?.[0] || (await el.addLanguage(env, g.projectId, target, l.model)).language_id;
      await persist();
      continue;
    }
    const lt = await el.getLanguage(env, g.projectId, l.languageId);
    if (lt.status === 'completed' && lt.outputs?.lossless_audio) {
      const key = `orders/${order.id}/dub-${target}.flac`;
      await copyToR2(env, lt.outputs.lossless_audio, key, 'audio/flac');
      l.status = 'done';
      l.key = key;
      await persist();
    } else if (lt.status === 'failed') {
      const projectFailed = lt.error?.code === 'project_failed';
      if (!projectFailed && l.attempts < 2) {
        l.languageId = (await el.addLanguage(env, g.projectId, target, l.model)).language_id;
        l.attempts += 1;
      } else {
        l.status = 'failed';
        l.reason = errorText(lt.error);
      }
      await persist();
    }
  }

  const states = order.targets.map((t) => d.langs[t]?.status);
  if (!states.every((s) => s === 'done' || s === 'failed')) return;

  const failed = order.targets.filter((t) => d.langs[t].status === 'failed');
  if (failed.length === order.targets.length) {
    await refund(env, order, order.price_cents, 'dub-failed');
    order.status = 'failed';
    d.error = 'Dubbing didn\u2019t work for this video. You\u2019ve been refunded in full.';
    return persist();
  }
  if (failed.length) {
    const share = Math.floor(order.price_cents * failed.length / order.targets.length);
    await refund(env, order, share, `lang-failed-${failed.join('-')}`);
    (d.notes ||= []).push(`${failed.map((t) => LANGS[t].name).join(' and ')} didn\u2019t work, so that part was refunded.`);
  }
  order.status = order.lipsync ? 'lipsync' : 'ready';
  if (order.lipsync) d.lipsyncStarted = Date.now();
  return persist();
}

async function advanceLipsync(env, origin, order, persist) {
  const d = order.data;
  d.lips ||= {};
  const done = order.targets.filter((t) => d.langs[t]?.status === 'done');
  const waitedHours = (Date.now() - (d.lipsyncStarted || Date.now())) / 3_600_000;

  for (const t of done) {
    const ls = (d.lips[t] ||= { status: 'waiting' });
    const wavKey = d.files[`lips-${t}`];
    if (ls.status === 'waiting') {
      if (d.files.video && wavKey) {
        const job = await lips.create(env, await mediaUrl(env, origin, d.files.video, 24 * 3600), await mediaUrl(env, origin, wavKey, 24 * 3600));
        ls.id = job.id;
        ls.status = 'processing';
        await persist();
      } else if (waitedHours > 6) {
        ls.status = 'failed';
        ls.reason = 'video not uploaded';
        await persist();
      }
    } else if (ls.status === 'processing') {
      const job = await lips.get(env, ls.id);
      if (job.status === 'COMPLETED' && job.outputUrl) {
        const key = `orders/${order.id}/lipsync-${t}.mp4`;
        await copyToR2(env, job.outputUrl, key, 'video/mp4');
        ls.status = 'done';
        ls.key = key;
        await persist();
      } else if (['FAILED', 'REJECTED', 'CANCELED', 'TIMED_OUT'].includes(job.status)) {
        ls.status = 'failed';
        ls.reason = job.error || job.status;
        await persist();
      }
    }
  }

  if (!done.every((t) => ['done', 'failed'].includes(d.lips[t]?.status))) return;
  const failed = done.filter((t) => d.lips[t].status === 'failed');
  if (failed.length) {
    const q = d.quote || quote(env, order.duration || order.client_duration, order.targets.length, true);
    const share = Math.floor(q.lipsyncCents * failed.length / order.targets.length);
    await refund(env, order, share, `lipsync-failed-${failed.join('-')}`);
    (d.notes ||= []).push('Lip matching didn\u2019t work for part of this order, so that part was refunded. Your dub is still ready.');
  }
  order.status = 'ready';
  return persist();
}

// What the browser is allowed to see.
async function publicView(env, origin, order) {
  const d = order.data;
  const q = d.quote || quote(env, order.duration || order.client_duration, order.targets.length, order.lipsync);
  const out = {
    id: order.id,
    status: order.status,
    source: order.source,
    targets: order.targets,
    lipsync: order.lipsync,
    duration: order.duration || order.client_duration,
    priceCents: order.price_cents,
    quote: q,
    refundedCents: d.refundedCents || 0,
    error: d.error || null,
    notes: d.notes || [],
    previewAudio: d.files?.previewDub ? await mediaUrl(env, origin, d.files.previewDub) : null,
    langs: [],
    needs: { video: false, wav: [] },
  };
  for (const t of order.targets) {
    const l = d.langs?.[t];
    const ls = d.lips?.[t];
    out.langs.push({
      lang: t,
      status: l?.status || (['paid', 'dubbing'].includes(order.status) ? 'processing' : 'waiting'),
      audio: l?.status === 'done' ? await mediaUrl(env, origin, l.key) : null,
      lipsync: order.lipsync ? { status: ls?.status || 'waiting', video: ls?.status === 'done' ? await mediaUrl(env, origin, ls.key) : null } : null,
    });
    if (order.status === 'lipsync' && l?.status === 'done' && !d.files?.[`lips-${t}`] && (!ls || ls.status === 'waiting')) out.needs.wav.push(t);
  }
  out.needs.video = order.lipsync && ['paid', 'dubbing', 'lipsync'].includes(order.status) && !d.files?.video;
  return out;
}

// ── Uploads (R2 multipart, 50 MiB parts, straight from the browser) ──────────
const PART_SIZE = 50 * 1024 * 1024;
const UPLOAD_RULES = {
  preview: { statuses: ['created'], exts: ['m4a', 'mp3', 'ogg', 'flac', 'wav'], maxBytes: 60e6 },
  audio:   { statuses: ['created'], exts: ['m4a', 'mp3', 'ogg', 'flac', 'wav'], maxBytes: 1.5e9 },
  video:   { statuses: ['paid', 'dubbing', 'lipsync'], exts: ['mp4'], maxBytes: 4e9, lipsyncOnly: true },
  lips:    { statuses: ['lipsync'], exts: ['wav', 'mp3'], maxBytes: 1e9, lipsyncOnly: true },
};
const MIME = { m4a: 'audio/mp4', mp3: 'audio/mpeg', ogg: 'audio/ogg', flac: 'audio/flac', wav: 'audio/wav', mp4: 'video/mp4' };

function uploadRule(order, kind) {
  const [base, lang] = kind.split('-');
  const rule = UPLOAD_RULES[base];
  if (!rule) bad('Unknown upload');
  if (base === 'lips' && !order.targets.includes(lang)) bad('Unknown language');
  if (rule.lipsyncOnly && !order.lipsync) bad('Lip sync not ordered');
  if (!rule.statuses.includes(order.status)) bad('Upload not allowed right now');
  return rule;
}

// ── HTTP routes ──────────────────────────────────────────────────────────────
async function handleApi(request, env, ctx) {
  const url = new URL(request.url);
  const origin = env.PUBLIC_ORIGIN || url.origin;
  const path = url.pathname.replace(/\/+$/, '');
  const method = request.method;
  const s = settings(env);
  let m;

  if (path === '/api/config' && method === 'GET') {
    return json({
      languages: Object.entries(LANGS).map(([id, l]) => ({ id, name: l.name, native: l.native })),
      pricing: { perMinCents: s.perMin, minCents: s.minPrice, lipsyncPerMinCents: s.lipPerMin },
      maxMinutes: s.maxMinutes, previewSeconds: s.previewSeconds, maxTargets: s.maxTargets,
      lipsync: { enabled: s.lipsyncEnabled, maxMinutes: s.lipMaxMinutes },
      stripePublishableKey: env.STRIPE_PUBLISHABLE_KEY || null,
      turnstileSiteKey: env.TURNSTILE_SITE_KEY || null,
      supportEmail: env.SUPPORT_EMAIL || null,
      ready: !!(env.ELEVENLABS_API_KEY && env.STRIPE_SECRET_KEY && env.STRIPE_PUBLISHABLE_KEY && env.MEDIA_SIGNING_SECRET),
    });
  }

  if ((m = path.match(/^\/api\/media\/(orders\/[A-Za-z0-9]+\/[A-Za-z0-9._-]+)$/)) && (method === 'GET' || method === 'HEAD')) {
    return serveMedia(env, request, m[1], url);
  }

  if (path === '/api/stripe/webhook' && method === 'POST') {
    const payload = await request.text();
    if (!env.STRIPE_WEBHOOK_SECRET || !(await verifyStripeSignature(env, payload, request.headers.get('stripe-signature')))) {
      return json({ error: 'bad signature' }, 400);
    }
    const event = JSON.parse(payload);
    const session = event.data?.object;
    const orderId = session?.metadata?.order_id;
    if (['checkout.session.completed', 'checkout.session.async_payment_succeeded'].includes(event.type) && orderId && session.payment_status === 'paid') {
      const run = async () => {
        // A browser poll may hold the lock for a moment; keep trying so the payment is never missed.
        for (let attempt = 0; attempt < 20; attempt++) {
          const got = await withLock(env, orderId, async (o) => {
            if (!o) return;
            const persist = () => saveOrder(env, o);
            if (markPaid(o, session)) await persist();
            await advance(env, origin, o, persist).catch((e) => console.error('advance after webhook', e));
          });
          if (got) return;
          await new Promise((r) => setTimeout(r, 1500));
        }
      };
      ctx.waitUntil(run());
    }
    return json({ received: true });
  }

  if (path === '/api/orders' && method === 'POST') {
    if (!(env.ELEVENLABS_API_KEY && env.STRIPE_SECRET_KEY && env.MEDIA_SIGNING_SECRET)) throw new HttpError(503, 'Dubbing is temporarily unavailable. Please check back soon.');
    const body = await request.json().catch(() => bad('Bad request'));
    const ip = request.headers.get('cf-connecting-ip') || '';
    const source = String(body.source || '');
    const targets = Array.isArray(body.targets) ? [...new Set(body.targets.map(String))] : [];
    const duration = Number(body.duration);
    const lipsync = !!body.lipsync;
    if (!LANGS[source]) bad('Pick the language you speak');
    if (!targets.length || targets.length > s.maxTargets || targets.some((t) => !LANGS[t] || t === source)) bad('Pick up to 3 other languages');
    if (!(duration > 0) || duration > s.maxMinutes * 60 + 1) bad(`Videos can be up to ${s.maxMinutes} minutes`);
    if (lipsync && (!s.lipsyncEnabled || duration > s.lipMaxMinutes * 60 + 1)) bad(`Lip matching works on videos up to ${s.lipMaxMinutes} minutes`);
    if (!(await verifyTurnstile(env, body.turnstile, ip))) throw new HttpError(403, 'Please complete the check and try again');
    const recent = await env.DB.prepare('SELECT COUNT(*) AS n FROM orders WHERE ip = ? AND created_at > ?').bind(ip, Date.now() - 3_600_000).first();
    if (recent && recent.n >= s.ordersPerHour) throw new HttpError(429, 'Too many previews from your connection. Try again in an hour.');

    const id = randomHex(12);
    const secret = randomHex(24);
    const q = quote(env, duration, targets.length, lipsync);
    const now = Date.now();
    await env.DB.prepare(`INSERT INTO orders (id, secret_hash, status, created_at, updated_at, ip, source, targets, lipsync, client_duration, price_cents, data)
      VALUES (?, ?, 'created', ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(id, await sha256(secret), now, now, ip, source, JSON.stringify(targets), lipsync ? 1 : 0, duration, q.totalCents,
        JSON.stringify({ files: {}, uploads: {}, quote: q, origin })).run();
    return json({ id, secret, quote: q, partSize: PART_SIZE });
  }

  if ((m = path.match(/^\/api\/orders\/([a-f0-9]{24})(\/.*)?$/))) {
    const id = m[1];
    const sub = m[2] || '';
    const order = await authOrder(env, request, id);
    const d = order.data;

    if (sub === '' && method === 'GET') {
      if (['previewing', 'preview_ready', 'paid', 'dubbing', 'lipsync'].includes(order.status)) {
        await withLock(env, id, async (o) => {
          await advance(env, origin, o, () => saveOrder(env, o)).catch((e) => console.error('advance', id, e));
        });
      }
      return json(await publicView(env, origin, await loadOrder(env, id)));
    }

    let um;
    if ((um = sub.match(/^\/uploads\/([a-z]+(?:-[a-z]+)?)$/)) && method === 'POST') {
      const kind = um[1];
      const rule = uploadRule(order, kind);
      const { ext } = await request.json().catch(() => ({}));
      if (!rule.exts.includes(ext)) bad('Unsupported file type');
      const key = `orders/${id}/${kind}.${ext}`;
      const mpu = await env.MEDIA.createMultipartUpload(key, { httpMetadata: { contentType: MIME[ext] } });
      await withLock(env, id, async (o) => { o.data.uploads[kind] = { key, uploadId: mpu.uploadId }; await saveOrder(env, o); });
      return json({ uploadId: mpu.uploadId, partSize: PART_SIZE });
    }

    if ((um = sub.match(/^\/uploads\/([a-z]+(?:-[a-z]+)?)\/(\d{1,5})$/)) && method === 'PUT') {
      const [, kind, partStr] = um;
      uploadRule(order, kind);
      const up = d.uploads?.[kind];
      if (!up || up.uploadId !== request.headers.get('x-upload-id')) bad('Upload not started');
      const len = Number(request.headers.get('content-length'));
      if (!(len > 0) || len > PART_SIZE) bad('Bad part size');
      const part = await env.MEDIA.resumeMultipartUpload(up.key, up.uploadId).uploadPart(Number(partStr), request.body);
      return json(part);
    }

    if ((um = sub.match(/^\/uploads\/([a-z]+(?:-[a-z]+)?)\/complete$/)) && method === 'POST') {
      const kind = um[1];
      const rule = uploadRule(order, kind);
      const up = d.uploads?.[kind];
      const { parts } = await request.json().catch(() => ({}));
      if (!up || !Array.isArray(parts) || !parts.length) bad('Upload not started');
      const obj = await env.MEDIA.resumeMultipartUpload(up.key, up.uploadId).complete(parts);
      if (obj.size > rule.maxBytes) { await env.MEDIA.delete(up.key); bad('File too large'); }

      // Check lengths on the server: price comes from the real audio, and the preview must be short.
      let result = {};
      if (kind === 'preview' || kind === 'audio') {
        let seconds = null;
        try { seconds = await r2Duration(env, up.key); } catch (e) { console.error('duration', e); }
        if (kind === 'preview' && (seconds === null || seconds > s.previewSeconds + 3)) { await env.MEDIA.delete(up.key); bad('Preview clip is too long'); }
        if (kind === 'audio') {
          if (seconds !== null && seconds > s.maxMinutes * 60 + 1) { await env.MEDIA.delete(up.key); bad(`Videos can be up to ${s.maxMinutes} minutes`); }
          result.duration = seconds;
        }
      }
      await withLock(env, id, async (o) => {
        o.data.files[kind] = up.key;
        delete o.data.uploads[kind];
        if (kind === 'audio' && result.duration) {
          o.duration = result.duration;
          o.data.quote = quote(env, Math.max(result.duration, o.client_duration * 0.97), o.targets.length, o.lipsync);
          o.price_cents = o.data.quote.totalCents;
        }
        await saveOrder(env, o);
      });
      return json({ ok: true, ...result });
    }

    if (sub === '/preview' && method === 'POST') {
      if (order.status !== 'created') return json(await publicView(env, origin, order));
      if (!d.files.preview || !d.files.audio) bad('Upload the audio first');
      await withLock(env, id, async (o) => {
        o.status = 'previewing';
        await saveOrder(env, o);
        await advance(env, origin, o, () => saveOrder(env, o)).catch((e) => console.error('preview start', e));
      });
      return json(await publicView(env, origin, await loadOrder(env, id)));
    }

    if (sub === '/checkout' && method === 'POST') {
      if (order.status !== 'preview_ready') bad('Preview isn\u2019t ready');
      const q = d.quote;
      const names = order.targets.map((t) => LANGS[t].name).join(', ');
      const items = [{ quantity: 1, price_data: { currency: 'usd', unit_amount: q.dubCents,
        product_data: { name: 'Ultradub dubbing', description: `${q.minutes} min video in ${names}` } } }];
      if (q.lipsyncCents) items.push({ quantity: 1, price_data: { currency: 'usd', unit_amount: q.lipsyncCents,
        product_data: { name: 'Lip matching', description: `${q.minutes} min, ${order.targets.length} language(s)` } } });
      const session = await stripe.call(env, 'POST', '/checkout/sessions', {
        mode: 'payment', ui_mode: 'embedded', redirect_on_completion: 'never',
        line_items: items,
        metadata: { order_id: id },
        payment_intent_data: { metadata: { order_id: id } },
      });
      await withLock(env, id, async (o) => { o.data.sessionId = session.id; await saveOrder(env, o); });
      return json({ clientSecret: session.client_secret });
    }

    throw new HttpError(404, 'Not found');
  }

  throw new HttpError(404, 'Not found');
}

// ── Cron: keep paid jobs moving when nobody has the page open; clean up old files ──
async function scheduled(env) {
  {
    const { results } = await env.DB.prepare(
      `SELECT id FROM orders WHERE lock_until < ? AND (status IN ('previewing','paid','dubbing','lipsync')
         OR (status = 'preview_ready' AND json_extract(data, '$.sessionId') IS NOT NULL AND updated_at > ?))
       ORDER BY updated_at LIMIT 25`
    ).bind(Date.now(), Date.now() - 6 * 3_600_000).all();
    for (const { id } of results) {
      await withLock(env, id, async (o) => {
        const origin = env.PUBLIC_ORIGIN || o.data.origin;   // the site address this order was placed on
        if (!origin) return;
        await advance(env, origin, o, () => saveOrder(env, o)).catch((e) => console.error('cron advance', id, e));
      });
    }
  }
  const cutoff = Date.now() - settings(env).keepHours * 3_600_000;
  const { results: old } = await env.DB.prepare(
    `SELECT id FROM orders WHERE created_at < ? AND status NOT IN ('expired') LIMIT 50`
  ).bind(cutoff).all();
  for (const { id } of old) {
    let cursor;
    do {
      const list = await env.MEDIA.list({ prefix: `orders/${id}/`, cursor });
      if (list.objects.length) await env.MEDIA.delete(list.objects.map((o) => o.key));
      cursor = list.truncated ? list.cursor : undefined;
    } while (cursor);
    await env.DB.prepare(`UPDATE orders SET status = 'expired', data = '{}' WHERE id = ?`).bind(id).run();
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    try {
      return await handleApi(request, env, ctx);
    } catch (e) {
      if (e instanceof HttpError) return json({ error: e.message }, e.status);
      console.error('api error', url.pathname, e);
      return json({ error: 'Something went wrong on our side. Please try again.' }, 500);
    }
  },
  async scheduled(event, env, ctx) {
    ctx.waitUntil(scheduled(env));
  },
};

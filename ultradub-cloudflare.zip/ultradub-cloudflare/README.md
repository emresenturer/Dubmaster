# Ultradub on Cloudflare

Customers upload a video they recorded, pick up to 3 languages, watch a free 20-second preview, pay, and download their video dubbed in their own voice. Optional lip matching.

How it works under the hood:

- The browser pulls the sound out of the video (no re-encoding, takes seconds) and uploads only the sound. The picture never leaves the customer's device, so 4K and hour-long videos work.
- ElevenLabs Dubbing v2 does translation, voice cloning and background preservation. Bengali runs on their v1 model automatically.
- The preview dubs only the first 20 seconds, so a free preview costs you about $0.17.
- After payment the full sound is dubbed. The browser puts the dubbed sound back onto the original picture and saves an MP4.
- Lip matching (sync.so) uploads the video only for customers who pay for it.
- Anything that fails after payment is refunded automatically, per language. Files are deleted after 48 hours.

## Your numbers

Costs include the free preview (about $0.17 of ElevenLabs time).

| Order | Customer pays | Your costs | You keep |
|---|---|---|---|
| 3 min, 1 language | $5.99 | $1.67 ElevenLabs + $0.47 Stripe | about $3.85 |
| 10 min, 2 languages | $30.00 | $10.17 ElevenLabs + $1.17 Stripe | about $18.65 |
| 1 min, 1 language, lip matching | $13.99 | $0.67 ElevenLabs + about $5.00 sync.so + $0.71 Stripe | about $7.60 |

Prices are settings in `wrangler.jsonc` (in cents): `PRICE_PER_MIN_CENTS` 150, `MIN_PRICE_CENTS` 599, `LIPSYNC_PER_MIN_CENTS` 800.

## Setup (about 30 minutes, all in the browser)

### 1. Put the code on GitHub
Create a new **private** repository called `ultradub`. Upload everything in this folder (drag the files and folders onto the "uploading an existing file" page).

### 2. Create storage in Cloudflare
1. Cloudflare dashboard, **R2 Object Storage**, **Create bucket**, name it `ultradub-media`. (R2 asks for a payment method once; the free allowance covers this app.)
2. **Storage & Databases**, **D1 SQL Database**, **Create**, name it `ultradub`. Copy the **Database ID**.
3. In GitHub, open `wrangler.jsonc`, click the pencil, replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with that ID, commit.
4. Back in D1, open `ultradub`, go to **Console**, paste everything from `migrations/0001_init.sql`, click **Execute**.

### 3. Deploy from GitHub
**Workers & Pages**, **Create**, **Import a repository**, connect GitHub, pick `ultradub`, keep the default deploy command (`npx wrangler deploy`), **Deploy**. You get a link like `https://ultradub.yourname.workers.dev`. From now on every commit redeploys automatically.

### 4. Add your keys
Worker, **Settings**, **Variables and Secrets**, **Add**, type **Secret**:

| Name | Where to get it |
|---|---|
| `ELEVENLABS_API_KEY` | elevenlabs.io, Developers, API Keys. Needs a paid plan so dubs have no watermark. |
| `STRIPE_SECRET_KEY` | Stripe, Developers, API keys (`sk_test_...` first, `sk_live_...` when ready) |
| `STRIPE_WEBHOOK_SECRET` | From step 5 |
| `MEDIA_SIGNING_SECRET` | Make one up: 40+ random letters and numbers (a password generator works) |
| `SYNC_API_KEY` | sync.so, API keys. Leave it out and the lip matching option is hidden. |

Then edit `wrangler.jsonc` in GitHub and fill in the public settings under `vars`:
- `STRIPE_PUBLISHABLE_KEY`: your `pk_test_...` or `pk_live_...` key
- `SUPPORT_EMAIL`: the Ultradub support address shown in the footer

Plain settings live in `wrangler.jsonc` because each deploy overwrites plain variables set in the dashboard. Secrets set in the dashboard are kept.

### 5. Connect Stripe
Stripe, **Developers**, **Webhooks**, **Add endpoint**:
- URL: `https://YOUR-WORKER-ADDRESS/api/stripe/webhook`
- Events: `checkout.session.completed` and `checkout.session.async_payment_succeeded`

Copy the signing secret (`whsec_...`) into the `STRIPE_WEBHOOK_SECRET` secret.

### 6. Test with a real 30-second clip
Use Stripe test keys and the test card `4242 4242 4242 4242`. ElevenLabs and sync.so calls are real, so a test run costs a few cents. Check that:
1. The preview plays in your voice.
2. After paying, the full video saves and plays on your phone.
3. In Stripe, try a refund path once: pick a video with no speech (music only) and confirm the automatic refund appears.

Then switch both Stripe keys to live and update the webhook for live mode.

### 7. Before you promote it
- **Turnstile (bot protection):** Cloudflare, **Turnstile**, add a widget for your domain. Put the site key in `TURNSTILE_SITE_KEY` (wrangler.jsonc) and the secret in a `TURNSTILE_SECRET_KEY` secret. Each preview costs you money, so turn this on before running ads.
- **Workers Paid plan ($5/month):** copying finished dubs into storage can exceed the free plan's CPU limit on long videos.
- **Custom domain:** Worker, **Settings**, **Domains & Routes**, **Add**, **Custom domain**. Update the Stripe webhook URL to match.
- **Terms, privacy and refund policy pages:** Stripe expects these on the site. Add them as pages in `public/`.
- **Demo videos:** see `public/demo/README.txt`.

## Settings reference (`wrangler.jsonc` vars)

| Name | Default | Meaning |
|---|---|---|
| `PRICE_PER_MIN_CENTS` | 150 | Dubbing price per started minute, per language |
| `MIN_PRICE_CENTS` | 599 | Minimum dubbing charge per order |
| `LIPSYNC_PER_MIN_CENTS` | 800 | Lip matching price per started minute, per language |
| `MAX_MINUTES` | 60 | Longest video accepted |
| `LIPSYNC_MAX_MINUTES` | 5 | Longest video for lip matching. Match your sync.so plan's limit. |
| `LIPSYNC_MODEL` | lipsync-2-pro | sync.so model |
| `PREVIEW_SECONDS` | 20 | Length of the free preview |
| `MAX_TARGETS` | 3 | Languages per order |
| `ORDERS_PER_IP_PER_HOUR` | 6 | Free previews per connection per hour |
| `KEEP_HOURS` | 48 | When files are deleted |
| `PUBLIC_ORIGIN` | empty | Optional. Leave empty unless you serve the site on several domains. |

## Things to know
- **ElevenLabs limits:** self-serve plans run a few dubbing jobs at once. Extra orders wait and are retried every minute, so nothing is lost, but busy hours can be slower.
- **Saving very large videos on phones:** Chrome and Edge on computers write the finished video straight to disk. Other browsers build it in memory, which can fail above roughly 1.5 GB. The page tells customers to use a computer in that case.
- **Order links:** customers can reopen an order from the same device, or with the link shown after payment, for 48 hours.

## Local development
```
npm install
cp .dev.vars.example .dev.vars        # fill in test keys
npx wrangler d1 migrations apply ultradub --local
npm run dev                           # http://localhost:8787
```
Tests (need ffmpeg): `test/make-media.sh`, then `test/run-e2e.sh` (API with mock services) and `test/run-browser.sh` (full customer journey in headless Chromium).

## Licenses
`public/vendor/` contains unmodified builds of Mediabunny (MPL-2.0), its AAC encoder (MPL-2.0, based on FFmpeg's libavcodec, LGPL) and a FLAC decoder (MIT). Their licenses and source links are in `public/vendor/THIRD_PARTY_LICENSES.txt`. Keep that file when deploying.

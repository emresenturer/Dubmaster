-- Ultradub orders. One row per customer video.
CREATE TABLE IF NOT EXISTS orders (
  id               TEXT PRIMARY KEY,
  secret_hash      TEXT NOT NULL,
  status           TEXT NOT NULL,
  created_at       INTEGER NOT NULL,
  updated_at       INTEGER NOT NULL,
  lock_until       INTEGER NOT NULL DEFAULT 0,
  ip               TEXT,
  source           TEXT NOT NULL,
  targets          TEXT NOT NULL,
  lipsync          INTEGER NOT NULL DEFAULT 0,
  client_duration  REAL NOT NULL,
  duration         REAL,
  price_cents      INTEGER NOT NULL,
  data             TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status, updated_at);
CREATE INDEX IF NOT EXISTS idx_orders_ip ON orders (ip, created_at);

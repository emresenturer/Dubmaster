// Copies the browser builds of Mediabunny and the codec fallbacks into public/vendor.
// Run after changing versions in package.json:  npm run vendor
import { copyFileSync, mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
const out = 'public/vendor';
mkdirSync(out, { recursive: true });
const files = [
  ['node_modules/mediabunny/dist/bundles/mediabunny.min.mjs', 'mediabunny.min.mjs'],
  ['node_modules/@mediabunny/aac-encoder/dist/bundles/mediabunny-aac-encoder.min.mjs', 'mediabunny-aac-encoder.min.mjs'],
  ['node_modules/@wasm-audio-decoders/flac/dist/flac-decoder.min.js', 'flac-decoder.min.js'],
];
for (const [from, to] of files) copyFileSync(from, `${out}/${to}`);
const lic = (dir) => ['LICENSE', 'LICENSE.md', 'LICENSE.txt'].map((f) => `${dir}/${f}`).find(existsSync);
const pkgs = ['mediabunny', '@mediabunny/aac-encoder', '@wasm-audio-decoders/flac'];
let text = 'Third-party software bundled in this folder (unmodified builds from npm).\n\n';
for (const p of pkgs) {
  const meta = JSON.parse(readFileSync(`node_modules/${p}/package.json`, 'utf8'));
  const repo = typeof meta.repository === 'string' ? meta.repository : meta.repository?.url;
  text += `=== ${p} ${meta.version} (${meta.license})\nSource: ${repo || meta.homepage}\n\n`;
  const f = lic(`node_modules/${p}`);
  if (f) text += readFileSync(f, 'utf8') + '\n\n';
}
writeFileSync(`${out}/THIRD_PARTY_LICENSES.txt`, text);
console.log('vendored', files.length, 'files');
